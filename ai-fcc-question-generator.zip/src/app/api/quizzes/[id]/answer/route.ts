import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure";
import { questions } from "@/db/schema";
import { errorResponse, HttpError, readJson } from "@/lib/http";
import { loadQuiz, refreshCounters, toCorrection } from "@/lib/quiz";
import { isLetter } from "@/lib/types";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

/** Modo estudo: registra a resposta de UMA questão e devolve o comentário completo. */
export async function POST(req: Request, ctx: Ctx) {
  try {
    await ensureSchema();
    const { id } = await ctx.params;
    const body = await readJson(req);
    const answer = body.answer;
    if (!isLetter(answer)) throw new HttpError(400, "Alternativa inválida.");
    const data = await loadQuiz(id);
    if (!data) throw new HttpError(404, "Simulado não encontrado.");
    if (data.quiz.status === "generating") throw new HttpError(409, "As questões ainda estão sendo geradas.");
    const q = data.qs.find((x) => x.id === body.questionId);
    if (!q) throw new HttpError(404, "Questão não encontrada.");

    let row = q;
    if (!q.userAnswer && data.quiz.status !== "finished") {
      const [updated] = await db
        .update(questions)
        .set({ userAnswer: answer, isCorrect: answer === q.correct, answeredAt: new Date() })
        .where(and(eq(questions.id, q.id), isNull(questions.userAnswer)))
        .returning();
      if (updated) row = updated;
    }
    const quiz = await refreshCounters(id);
    return Response.json({
      questionId: row.id,
      userAnswer: row.userAnswer,
      correction: toCorrection(row),
      answeredCount: quiz.answeredCount,
      correctCount: quiz.correctCount,
      status: quiz.status,
    });
  } catch (err) {
    return errorResponse(err);
  }
}
