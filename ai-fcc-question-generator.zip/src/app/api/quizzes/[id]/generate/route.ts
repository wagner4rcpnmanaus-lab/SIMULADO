import { ensureSchema } from "@/db/ensure";
import { finalizeGeneration, generateForPositions } from "@/lib/generator";
import { errorResponse, HttpError, readJson, UUID_RE } from "@/lib/http";

export const dynamic = "force-dynamic";
export const maxDuration = 180;

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: Request, ctx: Ctx) {
  try {
    await ensureSchema();
    const { id } = await ctx.params;
    if (!UUID_RE.test(id)) throw new HttpError(404, "Simulado não encontrado.");
    const body = await readJson(req);

    if (body.finalize === true) {
      await finalizeGeneration(id);
      return Response.json({ ok: true });
    }

    const positions = Array.isArray(body.positions)
      ? Array.from(new Set(body.positions.map(Number).filter((n) => Number.isInteger(n) && n >= 1 && n <= 50))).slice(0, 5)
      : [];
    if (!positions.length) throw new HttpError(400, "Informe as posições a gerar.");
    const result = await generateForPositions(id, positions);
    return Response.json(result);
  } catch (err) {
    return errorResponse(err);
  }
}
