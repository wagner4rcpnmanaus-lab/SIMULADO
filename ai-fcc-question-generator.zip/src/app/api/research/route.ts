import { errorResponse, HttpError, readJson } from "@/lib/http";
import { runResearch } from "@/lib/research";

export const dynamic = "force-dynamic";
export const maxDuration = 180;

export async function POST(req: Request) {
  try {
    const body = await readJson(req);
    const subject = typeof body.subject === "string" ? body.subject.trim() : "";
    const cargo = typeof body.cargo === "string" ? body.cargo.trim().slice(0, 120) : "";
    if (subject.length < 2 || subject.length > 120) throw new HttpError(400, "Informe a matéria (entre 2 e 120 caracteres).");
    const result = await runResearch(subject, cargo || null, body.force === true);
    return Response.json(result);
  } catch (err) {
    return errorResponse(err);
  }
}
