import { getProvider } from "@/lib/ai";
import { BANK } from "@/lib/bank";
import { searchProvidersLabel } from "@/lib/search";
import type { EngineStatus } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET() {
  const p = getProvider();
  const status: EngineStatus = {
    ai: { id: p.id, label: p.label, model: p.model, premium: p.premium },
    search: searchProvidersLabel(),
    bankSize: BANK.length,
  };
  return Response.json(status);
}
