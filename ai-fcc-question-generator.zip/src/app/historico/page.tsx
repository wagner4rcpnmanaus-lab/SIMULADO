import type { Metadata } from "next";
import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure";
import { quizzes } from "@/db/schema";
import DeleteQuizButton from "@/components/DeleteQuizButton";
import { IconArrowRight, IconSpark } from "@/components/icons";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Histórico · Questões FCC Premium",
};

const fmt = new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short", timeZone: "America/Sao_Paulo" });

const STATUS: Record<string, string> = {
  generating: "Em geração",
  ready: "Em andamento",
  finished: "Concluído",
};

export default async function HistoricoPage() {
  await ensureSchema();
  const rows = await db.select().from(quizzes).orderBy(desc(quizzes.createdAt)).limit(60);
  const finished = rows.filter((r) => r.status === "finished");
  const totalAnswered = rows.reduce((s, r) => s + r.answeredCount, 0);
  const totalCorrect = rows.reduce((s, r) => s + r.correctCount, 0);
  const accuracy = totalAnswered ? Math.round((totalCorrect / totalAnswered) * 100) : 0;

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-zinc-500">Seu desempenho</p>
          <h1 className="mt-1 font-display text-4xl font-semibold text-metal">Histórico de simulados</h1>
        </div>
        <Link href="/" className="btn-primary">
          <IconSpark size={16} /> Novo simulado
        </Link>
      </div>

      <div className="grid gap-3 sm:grid-cols-4">
        {[
          { label: "Simulados", value: String(rows.length) },
          { label: "Concluídos", value: String(finished.length) },
          { label: "Questões respondidas", value: String(totalAnswered) },
          { label: "Aproveitamento geral", value: `${accuracy}%`, tone: accuracy >= 60 ? "text-emerald-400" : totalAnswered ? "text-red-400" : "text-zinc-100" },
        ].map((s) => (
          <div key={s.label} className="surface rounded-2xl p-5">
            <p className="text-[10px] uppercase tracking-[0.18em] text-zinc-500">{s.label}</p>
            <p className={`mt-2 font-display text-3xl font-semibold ${s.tone ?? "text-zinc-100"}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {rows.length === 0 ? (
        <div className="surface rounded-3xl p-10 text-center">
          <p className="font-display text-2xl text-zinc-100">Nenhum simulado ainda</p>
          <p className="mt-2 text-sm text-zinc-500">Pesquise os assuntos mais cobrados de uma matéria e gere seu primeiro caderno.</p>
        </div>
      ) : (
        <ul className="space-y-3">
          {rows.map((r) => {
            const pct = r.answeredCount ? Math.round((r.correctCount / r.answeredCount) * 100) : 0;
            const wrong = r.answeredCount - r.correctCount;
            return (
              <li key={r.id} className="surface flex flex-wrap items-center gap-4 rounded-2xl p-4 sm:p-5">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-display text-lg font-semibold text-zinc-100">{r.subject}</p>
                    <span className="rounded-full border border-zinc-700 px-2 py-0.5 text-[10px] uppercase tracking-wider text-zinc-400">
                      {r.mode === "simulado" ? "Simulado" : "Estudo"}
                    </span>
                    <span className="rounded-full bg-zinc-800 px-2 py-0.5 text-[10px] uppercase tracking-wider text-zinc-400">{STATUS[r.status] ?? r.status}</span>
                  </div>
                  <p className="mt-1 text-xs text-zinc-500">
                    {fmt.format(r.createdAt)} · {r.questionCount} questões{r.cargo ? ` · ${r.cargo}` : ""}
                  </p>
                  {r.answeredCount > 0 && (
                    <div className="mt-3 flex max-w-md items-center gap-3">
                      <div className="flex h-1.5 flex-1 overflow-hidden rounded-full bg-zinc-800">
                        <div className="h-full bg-emerald-500" style={{ width: `${(r.correctCount / r.questionCount) * 100}%` }} />
                        <div className="h-full bg-red-500" style={{ width: `${(wrong / r.questionCount) * 100}%` }} />
                      </div>
                      <span className="text-xs">
                        <span className="text-emerald-400">{r.correctCount} certas</span> · <span className="text-red-400">{wrong} erradas</span>
                      </span>
                    </div>
                  )}
                </div>
                {r.answeredCount > 0 && <p className={`font-display text-3xl font-semibold ${pct >= 60 ? "text-emerald-400" : "text-red-400"}`}>{pct}%</p>}
                <div className="flex items-center gap-2">
                  <Link href={`/simulado/${r.id}`} className="btn-ghost text-sm">
                    {r.status === "finished" ? "Revisar" : "Continuar"} <IconArrowRight size={15} />
                  </Link>
                  <DeleteQuizButton id={r.id} />
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
