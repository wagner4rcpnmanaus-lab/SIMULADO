import type { Metadata } from "next";
import Link from "next/link";
import type { ReactNode } from "react";
import EngineBadge from "@/components/EngineBadge";
import "./globals.css";

export const metadata: Metadata = {
  title: "Questões FCC Premium · Simulados inéditos no estilo Fundação Carlos Chagas",
  description:
    "Gere questões inéditas de nível médio no estilo FCC a partir dos assuntos mais cobrados, pesquisados nos grandes portais de concursos, com correção comentada e a letra da lei.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="font-sans antialiased">
        <div className="bg-grid pointer-events-none fixed inset-0" aria-hidden="true" />
        <header className="sticky top-0 z-40 border-b border-white/[0.06] bg-black/60 backdrop-blur-xl">
          <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3">
            <Link href="/" className="group flex items-center gap-3">
              <span className="grid size-9 place-items-center rounded-xl bg-linear-to-b from-zinc-50 to-zinc-400 font-display text-lg font-bold text-zinc-950 shadow-[0_8px_24px_-8px_rgba(255,255,255,0.45)]">
                Q
              </span>
              <span className="leading-tight">
                <span className="block font-display text-[17px] font-semibold tracking-wide text-zinc-100">Questões FCC</span>
                <span className="block text-[9.5px] font-medium uppercase tracking-[0.3em] text-zinc-500">Premium · Nível médio</span>
              </span>
            </Link>
            <nav className="flex items-center gap-1 text-sm">
              <Link href="/" className="rounded-lg px-3 py-2 text-zinc-400 transition hover:bg-white/5 hover:text-white">
                Novo simulado
              </Link>
              <Link href="/historico" className="rounded-lg px-3 py-2 text-zinc-400 transition hover:bg-white/5 hover:text-white">
                Histórico
              </Link>
              <EngineBadge />
            </nav>
          </div>
        </header>
        <main className="relative mx-auto max-w-6xl px-5 pb-24 pt-8">{children}</main>
        <footer className="relative border-t border-white/[0.06] py-8">
          <div className="mx-auto max-w-6xl px-5 text-center text-xs leading-relaxed text-zinc-600">
            Questões inéditas elaboradas no estilo da banca FCC exclusivamente para fins de estudo. Este sistema não tem vínculo
            com a Fundação Carlos Chagas. Confira sempre a redação vigente das normas nos sites oficiais.
          </div>
        </footer>
      </body>
    </html>
  );
}
