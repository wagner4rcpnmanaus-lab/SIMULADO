import type { Metadata } from "next";
import QuizPlayer from "@/components/QuizPlayer";

export const metadata: Metadata = {
  title: "Simulado · Questões FCC Premium",
};

export default async function SimuladoPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <QuizPlayer id={id} />;
}
