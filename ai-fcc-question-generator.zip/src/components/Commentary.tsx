import type { ReactNode } from "react";
import { isLegalReference } from "@/lib/laws";
import { LETTERS, type PublicQuestion } from "@/lib/types";
import { IconBook, IconBulb, IconCheck, IconExternal, IconQuote, IconScale, IconX } from "./icons";

function stripVerdict(text: string): string {
  return text.replace(/^\s*(correta|errada|certa|incorreta|alternativa correta|alternativa errada)\s*[.:!–-]?\s*/i, "");
}

export default function Commentary({ q }: { q: PublicQuestion }) {
  const c = q.correction;
  if (!c) return null;
  const legal = isLegalReference(c.legalBasis);
  const state = c.isCorrect === true ? "acertou" : c.isCorrect === false ? "errou" : "branco";

  const header =
    state === "acertou"
      ? { cls: "border-emerald-500/40 bg-emerald-500/10 text-emerald-200", icon: <IconCheck size={18} strokeWidth={2.4} />, text: "Você acertou!" }
      : state === "errou"
        ? { cls: "border-red-500/40 bg-red-500/10 text-red-200", icon: <IconX size={18} strokeWidth={2.4} />, text: `Você errou — marcou a alternativa ${q.userAnswer}.` }
        : { cls: "border-zinc-700 bg-zinc-900/70 text-zinc-300", icon: <IconBook size={18} />, text: "Questão deixada em branco." };

  const analysis = LETTERS.filter((L) => c.analysis[L]);

  return (
    <section className="mt-6 overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-950/60 animate-fade-up">
      <header className={`flex flex-wrap items-center justify-between gap-3 border-b px-5 py-3.5 ${header.cls}`}>
        <span className="flex items-center gap-2 text-sm font-semibold">
          {header.icon}
          {header.text}
        </span>
        <span className="flex items-center gap-2">
          {c.difficulty && <span className="rounded-md border border-current/20 px-2 py-0.5 text-[10px] uppercase tracking-wider opacity-80">{c.difficulty}</span>}
          <span className="rounded-lg bg-emerald-500 px-2.5 py-1 text-xs font-bold text-emerald-950">Gabarito: {c.correct}</span>
        </span>
      </header>

      <div className="space-y-6 p-5 sm:p-6">
        <Block icon={<IconBook size={15} />} title={`Explicação resumida · Foco em ${q.topic}`}>
          <p className="text-[15px] leading-relaxed text-zinc-300">{c.summary}</p>
        </Block>

        {c.legalBasis && (
          <Block icon={<IconScale size={15} />} title={legal ? "Fundamentação legal" : "Fundamentação"}>
            <div className="flex flex-wrap items-center gap-3">
              <span className="rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-1.5 text-sm font-medium text-zinc-100">{c.legalBasis}</span>
              {c.lawUrl && (
                <a
                  href={c.lawUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs text-zinc-400 underline-offset-4 hover:text-zinc-100 hover:underline"
                >
                  Ver texto oficial <IconExternal size={12} />
                </a>
              )}
            </div>
          </Block>
        )}

        {c.lawText && (
          <Block icon={<IconQuote size={15} />} title={legal ? "Letra da lei" : "Regra / conceito-chave"}>
            <blockquote className="whitespace-pre-line rounded-xl border-l-2 border-zinc-300 bg-zinc-900/60 px-5 py-4 font-display text-[15.5px] leading-relaxed text-zinc-200">
              {c.lawText}
            </blockquote>
          </Block>
        )}

        {analysis.length > 0 && (
          <Block icon={<IconCheck size={15} />} title="Análise das alternativas">
            <ul className="space-y-2">
              {analysis.map((L) => {
                const ok = L === c.correct;
                const mine = L === q.userAnswer;
                return (
                  <li
                    key={L}
                    className={`flex gap-3 rounded-xl border px-3.5 py-3 text-sm leading-relaxed ${
                      ok ? "border-emerald-500/40 bg-emerald-500/[0.07]" : mine ? "border-red-500/40 bg-red-500/[0.07]" : "border-zinc-800 bg-zinc-900/40"
                    }`}
                  >
                    <span
                      className={`grid size-7 shrink-0 place-items-center rounded-lg text-xs font-bold ${
                        ok ? "bg-emerald-500 text-emerald-950" : mine ? "bg-red-500 text-white" : "bg-zinc-800 text-zinc-300"
                      }`}
                    >
                      {L}
                    </span>
                    <p className="text-zinc-300">
                      <span className={`mr-1.5 font-semibold ${ok ? "text-emerald-400" : "text-red-400"}`}>{ok ? "Correta." : "Errada."}</span>
                      {stripVerdict(c.analysis[L] ?? "")}
                    </p>
                  </li>
                );
              })}
            </ul>
          </Block>
        )}

        {c.tip && (
          <div className="flex gap-3 rounded-xl border border-zinc-700/70 bg-linear-to-r from-zinc-800/60 to-zinc-900/40 p-4">
            <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-zinc-100 text-zinc-950">
              <IconBulb size={16} />
            </span>
            <p className="text-sm leading-relaxed text-zinc-300">
              <span className="font-semibold text-zinc-50">Dica FCC: </span>
              {c.tip}
            </p>
          </div>
        )}

        {q.origin === "ia-gratuita" && (
          <p className="rounded-xl border border-red-500/30 bg-red-500/[0.06] px-4 py-3 text-xs leading-relaxed text-red-200/90">
            Atenção: esta questão foi elaborada pela IA gratuita, de precisão limitada. Confira a fundamentação em fonte oficial antes de
            memorizá-la. Para máxima confiabilidade, configure uma IA premium (OPENAI_API_KEY, GEMINI_API_KEY ou ANTHROPIC_API_KEY).
          </p>
        )}

        <p className="text-[11px] leading-relaxed text-zinc-600">
          {q.origin === "banco"
            ? "Questão do banco curado, com transcrição legal conferida."
            : `Questão e comentário elaborados por IA (${q.engine ?? "IA"}). Confira sempre a redação vigente no texto oficial.`}
        </p>
      </div>
    </section>
  );
}

function Block({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) {
  return (
    <div>
      <h4 className="mb-2.5 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-zinc-500">
        {icon}
        {title}
      </h4>
      {children}
    </div>
  );
}
