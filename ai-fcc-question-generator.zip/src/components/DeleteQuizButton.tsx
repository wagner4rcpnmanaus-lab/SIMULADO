"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { IconTrash } from "./icons";

export default function DeleteQuizButton({ id }: { id: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function remove() {
    if (!window.confirm("Excluir este simulado do histórico?")) return;
    setBusy(true);
    try {
      await fetch(`/api/quizzes/${id}`, { method: "DELETE" });
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <button
      type="button"
      onClick={() => void remove()}
      disabled={busy}
      className="grid size-9 place-items-center rounded-xl border border-zinc-800 text-zinc-500 transition hover:border-red-500/50 hover:text-red-400 disabled:opacity-40"
      aria-label="Excluir simulado"
      title="Excluir"
    >
      <IconTrash size={15} />
    </button>
  );
}
