"use client";

import { useEffect, useRef, useState } from "react";
import type { EngineStatus } from "@/lib/types";

export default function EngineBadge() {
  const [status, setStatus] = useState<EngineStatus | null>(null);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch("/api/status", { cache: "no-store" })
      .then((r) => r.json())
      .then((d: EngineStatus) => setStatus(d))
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  if (!status) return <span className="ml-1 hidden h-8 w-32 rounded-full skeleton sm:block" />;
  const premium = status.ai.premium;

  return (
    <div className="relative ml-1" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-2 rounded-full border border-zinc-700/70 bg-zinc-900/70 px-3 py-1.5 text-xs text-zinc-300 transition hover:border-zinc-500"
        aria-expanded={open}
      >
        <span
          className={`size-2 rounded-full ${premium ? "bg-zinc-100 shadow-[0_0_10px_rgba(255,255,255,0.9)]" : "bg-zinc-500 animate-pulse-soft"}`}
        />
        <span className="hidden sm:inline">{premium ? `IA: ${status.ai.label}` : "Modo gratuito"}</span>
      </button>
      {open && (
        <div className="surface absolute right-0 top-11 z-50 w-80 rounded-2xl p-4 text-left text-xs leading-relaxed text-zinc-400 animate-fade-up">
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-zinc-500">Motor de questões</p>
          <p className="mt-1 text-sm font-medium text-zinc-100">
            {premium ? `${status.ai.label} · ${status.ai.model}` : "IA gratuita + banco curado"}
          </p>
          {!premium && (
            <p className="mt-2">
              Sem chave de IA configurada: o sistema prioriza o banco curado ({status.bankSize} questões com letra da lei
              conferida) e complementa com uma IA gratuita. Para questões inéditas ilimitadas e máxima precisão, defina{" "}
              <code className="text-zinc-200">OPENAI_API_KEY</code>, <code className="text-zinc-200">GEMINI_API_KEY</code> ou{" "}
              <code className="text-zinc-200">ANTHROPIC_API_KEY</code>.
            </p>
          )}
          <div className="hairline my-3" />
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-zinc-500">Busca nos portais</p>
          <p className="mt-1 text-zinc-300">{status.search.join(" · ")}</p>
        </div>
      )}
    </div>
  );
}
