"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { LETTERS, type Letter, type PublicQuestion, type PublicQuiz } from "@/lib/types";
import Commentary from "./Commentary";
import { IconArrowLeft, IconArrowRight, IconCheck, IconClock, IconLayers, IconRefresh, IconSpark, IconTarget, IconX } from "./icons";

type GenState = { done: number; total: number; running: boolean; message: string; error: string | null; failed: number[] };
type View = "quiz" | "results";
type Filter = "todas" | "erradas" | "certas" | "branco";
type OptState = "idle" | "selected" | "correct" | "wrong" | "dim";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function optState(q: PublicQuestion, L: Letter, pick?: Letter): OptState {
  if (q.revealed && q.correction) {
    if (L === q.correction.correct) return "correct";
    if (L === q.userAnswer) return "wrong";
    return "dim";
  }
  return pick === L ? "selected" : "idle";
}

function originLabel(q: PublicQuestion): string {
  if (q.origin === "banco") return "Banco curado · letra da lei conferida";
  if (q.origin === "ia-gratuita") return "IA gratuita · conferir fundamentação";
  return q.engine ?? "IA premium";
}

function fmtTime(s: number): string {
  const m = Math.floor(s / 60);
  return `${String(m).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

export default function QuizPlayer({ id }: { id: string }) {
  const router = useRouter();
  const [quiz, setQuiz] = useState<PublicQuiz | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [gen, setGen] = useState<GenState | null>(null);
  const [view, setView] = useState<View>("quiz");
  const [idx, setIdx] = useState(0);
  const [picks, setPicks] = useState<Record<string, Letter>>({});
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [confirmFinish, setConfirmFinish] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const genStarted = useRef(false);
  const storageKey = `fcc-picks-${id}`;

  const fetchQuiz = useCallback(async (): Promise<PublicQuiz> => {
    const res = await fetch(`/api/quizzes/${id}`, { cache: "no-store" });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Simulado não encontrado.");
    return data as PublicQuiz;
  }, [id]);

  const runGeneration = useCallback(
    async (q: PublicQuiz) => {
      const existing = new Set(q.questions.map((x) => x.position));
      const missing = q.plan.map((p) => p.position).filter((p) => !existing.has(p));
      const topicOf = new Map(q.plan.map((p) => [p.position, p.topic]));
      const size = Math.max(1, q.batchSize);
      const batches: number[][] = [];
      for (let i = 0; i < missing.length; i += size) batches.push(missing.slice(i, i + size));
      let done = existing.size;
      let lastError: string | null = null;
      const failed: number[] = [];
      setGen({ done, total: q.questionCount, running: true, message: "Preparando o caderno de questões…", error: null, failed: [] });

      let cursor = 0;
      const worker = async () => {
        while (cursor < batches.length) {
          const batch = batches[cursor++];
          let remaining = batch;
          setGen((g) => g && { ...g, message: `Elaborando questão sobre “${topicOf.get(batch[0]) ?? q.subject}”` });
          for (let attempt = 0; attempt < 3 && remaining.length; attempt++) {
            try {
              const res = await fetch(`/api/quizzes/${id}/generate`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ positions: remaining }),
              });
              const data = await res.json();
              if (!res.ok) throw new Error(data.error || "Falha ao gerar questões.");
              const stillMissing = (data.missing as number[]) ?? [];
              done += remaining.length - stillMissing.length;
              remaining = stillMissing;
              if (data.warning && remaining.length) lastError = data.warning as string;
              setGen((g) => g && { ...g, done: Math.min(done, g.total) });
            } catch (e) {
              lastError = (e as Error).message;
              await sleep(1500 * (attempt + 1));
            }
          }
          if (remaining.length) failed.push(...remaining);
        }
      };
      await Promise.all(Array.from({ length: Math.max(1, Math.min(q.concurrency, batches.length)) }, worker));

      if (!failed.length) {
        let fresh = await fetchQuiz();
        if (fresh.status === "generating") {
          await fetch(`/api/quizzes/${id}/generate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ finalize: true }) });
          fresh = await fetchQuiz();
        }
        setQuiz(fresh);
        setIdx(0);
        setGen(null);
      } else {
        setGen({ done, total: q.questionCount, running: false, message: "", error: lastError ?? "Algumas questões não puderam ser geradas.", failed });
      }
    },
    [id, fetchQuiz],
  );

  useEffect(() => {
    let alive = true;
    fetchQuiz()
      .then((q) => {
        if (!alive) return;
        setQuiz(q);
        if (q.status === "finished") setView("results");
        try {
          const saved = JSON.parse(localStorage.getItem(storageKey) || "{}") as Record<string, Letter>;
          if (saved && typeof saved === "object") setPicks(saved);
        } catch {
          /* ignora */
        }
        const first = q.questions.findIndex((x) => !x.userAnswer);
        setIdx(first >= 0 ? first : 0);
        if (q.status === "generating" && !genStarted.current) {
          genStarted.current = true;
          void runGeneration(q);
        }
      })
      .catch((e: Error) => alive && setLoadError(e.message));
    return () => {
      alive = false;
    };
  }, [fetchQuiz, runGeneration, storageKey]);

  const inQuiz = Boolean(quiz && quiz.status !== "generating" && view === "quiz" && !gen);
  useEffect(() => {
    if (!inQuiz || quiz?.status === "finished") return;
    const t = setInterval(() => setElapsed((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, [inQuiz, quiz?.status]);

  const current = quiz?.questions[idx];

  const choose = useCallback(
    (q: PublicQuestion, L: Letter) => {
      if (!quiz || q.revealed || quiz.status === "finished") return;
      const next = { ...picks, [q.id]: L };
      setPicks(next);
      try {
        localStorage.setItem(storageKey, JSON.stringify(next));
      } catch {
        /* ignora */
      }
    },
    [quiz, picks, storageKey],
  );

  const confirmAnswer = useCallback(
    async (q: PublicQuestion) => {
      const answer = picks[q.id];
      if (!answer || busy) return;
      setBusy(true);
      setActionError(null);
      try {
        const res = await fetch(`/api/quizzes/${id}/answer`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ questionId: q.id, answer }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Falha ao registrar a resposta.");
        setQuiz((cur) =>
          cur
            ? {
                ...cur,
                answeredCount: data.answeredCount,
                correctCount: data.correctCount,
                status: data.status,
                questions: cur.questions.map((x) =>
                  x.id === q.id ? { ...x, userAnswer: data.userAnswer, revealed: true, correction: data.correction } : x,
                ),
              }
            : cur,
        );
      } catch (e) {
        setActionError((e as Error).message);
      } finally {
        setBusy(false);
      }
    },
    [id, picks, busy],
  );

  async function finishQuiz() {
    setBusy(true);
    setActionError(null);
    try {
      const res = await fetch(`/api/quizzes/${id}/finish`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answers: picks }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Falha ao finalizar o simulado.");
      setQuiz(data as PublicQuiz);
      setView("results");
      setConfirmFinish(false);
      try {
        localStorage.removeItem(storageKey);
      } catch {
        /* ignora */
      }
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (e) {
      setActionError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function finalizePartial() {
    setBusy(true);
    try {
      await fetch(`/api/quizzes/${id}/generate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ finalize: true }) });
      const fresh = await fetchQuiz();
      setQuiz(fresh);
      setGen(null);
      setIdx(0);
    } catch (e) {
      setActionError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function retryGeneration() {
    const fresh = await fetchQuiz();
    setQuiz(fresh);
    await runGeneration(fresh);
  }

  async function newBatch() {
    if (!quiz) return;
    setBusy(true);
    try {
      const res = await fetch("/api/quizzes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subject: quiz.subject, cargo: quiz.cargo ?? "", topics: quiz.topics, count: Math.max(1, quiz.plan.length || quiz.questionCount), mode: quiz.mode }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Falha ao criar novo lote.");
      router.push(`/simulado/${data.id}`);
    } catch (e) {
      setActionError((e as Error).message);
      setBusy(false);
    }
  }

  // Atalhos de teclado: A–E marcam, Enter confirma, setas navegam.
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (!quiz || !current || !inQuiz) return;
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || e.metaKey || e.ctrlKey || e.altKey) return;
      const k = e.key.toUpperCase();
      if ((LETTERS as readonly string[]).includes(k)) choose(current, k as Letter);
      else if (e.key === "ArrowRight") setIdx((i) => Math.min(i + 1, quiz.questions.length - 1));
      else if (e.key === "ArrowLeft") setIdx((i) => Math.max(i - 1, 0));
      else if (e.key === "Enter" && quiz.mode === "estudo" && !current.revealed && picks[current.id]) void confirmAnswer(current);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [quiz, current, inQuiz, picks, choose, confirmAnswer]);

  /* ------------------------------- Estados ------------------------------- */

  if (loadError) {
    return (
      <div className="surface mx-auto max-w-xl rounded-3xl p-8 text-center">
        <p className="font-display text-2xl text-zinc-100">Simulado indisponível</p>
        <p className="mt-2 text-sm text-zinc-500">{loadError}</p>
        <Link href="/" className="btn-primary mt-6">
          Criar novo simulado
        </Link>
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="space-y-4">
        <div className="skeleton h-24 rounded-3xl" />
        <div className="skeleton h-96 rounded-3xl" />
      </div>
    );
  }

  if (gen || quiz.status === "generating") {
    const g = gen ?? { done: quiz.questions.length, total: quiz.questionCount, running: true, message: "Preparando…", error: null, failed: [] };
    const pct = Math.round((g.done / Math.max(1, g.total)) * 100);
    return (
      <div className="mx-auto max-w-2xl pt-6">
        <div className="surface rounded-3xl p-8 text-center animate-fade-up">
          <span className="mx-auto grid size-14 place-items-center rounded-2xl border border-zinc-700 bg-zinc-900">
            {g.running ? <IconSpark size={24} className="animate-pulse-soft" /> : <IconX size={24} className="text-red-400" />}
          </span>
          <h1 className="mt-5 font-display text-3xl font-semibold text-zinc-50">
            {g.running ? "Elaborando suas questões" : "Geração interrompida"}
          </h1>
          <p className="mt-2 text-sm text-zinc-500">
            {quiz.subject} · {quiz.questionCount} questões · estilo FCC · nível médio
          </p>
          <div className="mt-8 flex items-end justify-between text-xs text-zinc-500">
            <span>{g.running ? g.message : `${g.done} de ${g.total} questões prontas`}</span>
            <span className="font-display text-2xl text-zinc-100">{pct}%</span>
          </div>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-zinc-800">
            <div className={`h-full rounded-full transition-all duration-700 ${g.running ? "shimmer-bar" : "bg-zinc-400"}`} style={{ width: `${Math.max(4, pct)}%` }} />
          </div>
          <p className="mt-3 text-xs text-zinc-600">
            {g.done} de {g.total} prontas · questões inéditas com gabarito protegido até a sua resposta
          </p>
          {!g.running && (
            <div className="mt-6 space-y-4">
              <p className="rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-200">{g.error}</p>
              <div className="flex flex-wrap justify-center gap-3">
                <button type="button" className="btn-primary" onClick={() => void retryGeneration()} disabled={busy}>
                  <IconRefresh size={16} /> Tentar novamente
                </button>
                {g.done > 0 && (
                  <button type="button" className="btn-ghost" onClick={() => void finalizePartial()} disabled={busy}>
                    Começar com {g.done} questão(ões)
                  </button>
                )}
                <Link href="/" className="btn-ghost">
                  Voltar
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (!quiz.questions.length) {
    return (
      <div className="surface mx-auto max-w-xl rounded-3xl p-8 text-center">
        <p className="font-display text-2xl text-zinc-100">Nenhuma questão disponível</p>
        <Link href="/" className="btn-primary mt-6">
          Criar novo simulado
        </Link>
      </div>
    );
  }

  if (view === "results") {
    return <Results quiz={quiz} busy={busy} error={actionError} onNewBatch={() => void newBatch()} />;
  }

  /* ------------------------------- Resolução ------------------------------- */

  const q = current ?? quiz.questions[0];
  const total = quiz.questions.length;
  const answeredLocal = quiz.questions.filter((x) => x.userAnswer || picks[x.id]).length;
  const wrongCount = quiz.questions.filter((x) => x.revealed && x.correction?.isCorrect === false).length;
  const isLast = idx >= total - 1;
  const unanswered = total - answeredLocal;
  const study = quiz.mode === "estudo";

  return (
    <div className="space-y-6">
      <header className="surface flex flex-wrap items-center justify-between gap-4 rounded-3xl px-6 py-5">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1 rounded-full bg-zinc-100 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-zinc-950">
              <IconTarget size={11} /> Foco 100% no tema
            </span>
            <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-zinc-500">
              {study ? "Modo Estudo" : "Modo Simulado"} · estilo FCC · nível médio
            </p>
          </div>
          <h1 className="mt-1.5 font-display text-2xl font-semibold text-zinc-50">{quiz.subject}</h1>
          {quiz.cargo && <p className="text-xs text-zinc-500">{quiz.cargo}</p>}
        </div>
        <div className="flex flex-wrap items-center gap-5 text-sm">
          <Stat label="Respondidas" value={`${answeredLocal}/${total}`} />
          {study && <Stat label="Acertos" value={String(quiz.correctCount)} tone="green" />}
          {study && <Stat label="Erros" value={String(wrongCount)} tone="red" />}
          <Stat label="Tempo" value={fmtTime(elapsed)} icon={<IconClock size={13} />} />
        </div>
        <div className="h-1 w-full overflow-hidden rounded-full bg-zinc-800">
          <div className="h-full rounded-full bg-linear-to-r from-zinc-500 to-zinc-100 transition-all" style={{ width: `${(answeredLocal / total) * 100}%` }} />
        </div>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1fr_280px]">
        <article key={q.id} className="surface rounded-3xl p-6 sm:p-8 animate-fade-up">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="rounded-lg bg-zinc-100 px-2.5 py-1 font-bold text-zinc-950">Questão {idx + 1}</span>
            <span className="text-zinc-500">de {total}</span>
            <span className="rounded-full border border-zinc-700 px-2.5 py-1 text-zinc-300">{q.topic}</span>
            <span className="ml-auto text-[11px] text-zinc-600">{originLabel(q)}</span>
          </div>

          <QuestionBody q={q} pick={picks[q.id]} onChoose={(L) => choose(q, L)} />

          {actionError && <p className="mt-4 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-200">{actionError}</p>}

          <div className="mt-7 flex flex-wrap items-center justify-between gap-3 border-t border-zinc-800/80 pt-6">
            <button type="button" className="btn-ghost" onClick={() => setIdx((i) => Math.max(0, i - 1))} disabled={idx === 0}>
              <IconArrowLeft size={16} /> Anterior
            </button>
            <div className="flex flex-wrap gap-3">
              {study && !q.revealed && (
                <button type="button" className="btn-primary" onClick={() => void confirmAnswer(q)} disabled={!picks[q.id] || busy}>
                  {busy ? <IconRefresh size={16} className="animate-spin" /> : <IconCheck size={16} />} Confirmar resposta
                </button>
              )}
              {study && q.revealed && quiz.status === "finished" && (
                <button type="button" className="btn-primary" onClick={() => setView("results")}>
                  <IconTarget size={16} /> Ver desempenho final
                </button>
              )}
              {!isLast && (!study || q.revealed) && (
                <button type="button" className={study ? "btn-primary" : "btn-ghost"} onClick={() => setIdx((i) => Math.min(total - 1, i + 1))}>
                  Próxima <IconArrowRight size={16} />
                </button>
              )}
              {!study && isLast && (
                <button type="button" className="btn-primary" onClick={() => (unanswered > 0 ? setConfirmFinish(true) : void finishQuiz())} disabled={busy}>
                  <IconTarget size={16} /> Finalizar e corrigir
                </button>
              )}
            </div>
          </div>

          {q.revealed && <Commentary q={q} />}
        </article>

        <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <div className="surface rounded-3xl p-5">
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-zinc-500">Caderno de questões</p>
            <div className="mt-4 grid grid-cols-5 gap-2">
              {quiz.questions.map((x, i) => {
                const c = x.correction;
                const cls =
                  x.revealed && c
                    ? c.isCorrect
                      ? "bg-emerald-500 text-emerald-950 border-emerald-400"
                      : c.isCorrect === false
                        ? "bg-red-500 text-white border-red-400"
                        : "bg-zinc-800 text-zinc-400 border-zinc-700"
                    : picks[x.id]
                      ? "bg-zinc-300 text-zinc-950 border-zinc-200"
                      : "bg-zinc-900 text-zinc-400 border-zinc-800 hover:border-zinc-600";
                return (
                  <button
                    key={x.id}
                    type="button"
                    onClick={() => setIdx(i)}
                    className={`grid h-10 place-items-center rounded-xl border text-sm font-semibold transition ${cls} ${i === idx ? "ring-2 ring-zinc-100 ring-offset-2 ring-offset-zinc-950" : ""}`}
                    aria-label={`Ir para a questão ${i + 1}`}
                  >
                    {i + 1}
                  </button>
                );
              })}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2 text-[11px] text-zinc-500">
              {study ? (
                <>
                  <Legend cls="bg-emerald-500" label="Certa" />
                  <Legend cls="bg-red-500" label="Errada" />
                </>
              ) : (
                <Legend cls="bg-zinc-300" label="Respondida" />
              )}
              <Legend cls="bg-zinc-900 border border-zinc-700" label="Pendente" />
            </div>
          </div>

          <div className="surface rounded-3xl p-5 text-sm">
            {study ? (
              <>
                <p className="text-xs leading-relaxed text-zinc-500">Cada resposta confirmada libera o gabarito e o comentário completo da questão.</p>
                <button type="button" className="btn-ghost mt-4 w-full text-sm" onClick={() => void finishQuiz()} disabled={busy}>
                  Encerrar e ver resultado
                </button>
              </>
            ) : (
              <>
                <p className="text-xs leading-relaxed text-zinc-500">
                  {unanswered > 0 ? `${unanswered} questão(ões) sem resposta.` : "Todas as questões foram respondidas."} Os comentários serão liberados ao
                  finalizar.
                </p>
                <button type="button" className="btn-primary mt-4 w-full text-sm" onClick={() => (unanswered > 0 ? setConfirmFinish(true) : void finishQuiz())} disabled={busy}>
                  <IconTarget size={16} /> Finalizar simulado
                </button>
              </>
            )}
            <p className="mt-4 hidden items-center gap-1.5 text-[11px] text-zinc-600 lg:flex">
              Atalhos: <span className="kbd">A</span>–<span className="kbd">E</span> marcar · <span className="kbd">←</span>
              <span className="kbd">→</span> navegar{study && <> · <span className="kbd">Enter</span> confirmar</>}
            </p>
          </div>
        </aside>
      </div>

      {confirmFinish && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="surface w-full max-w-md rounded-3xl p-6 animate-fade-up">
            <p className="font-display text-xl text-zinc-50">Finalizar com questões em branco?</p>
            <p className="mt-2 text-sm text-zinc-400">
              Você deixou {unanswered} questão(ões) sem resposta. Elas serão contadas como não respondidas, mas também receberão o comentário completo.
            </p>
            <div className="mt-6 flex justify-end gap-3">
              <button type="button" className="btn-ghost" onClick={() => setConfirmFinish(false)}>
                Continuar respondendo
              </button>
              <button type="button" className="btn-primary" onClick={() => void finishQuiz()} disabled={busy}>
                Finalizar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------ Subcomponentes ------------------------------ */

function QuestionBody({ q, pick, onChoose }: { q: PublicQuestion; pick?: Letter; onChoose?: (L: Letter) => void }) {
  return (
    <>
      {q.supportText && (
        <div className="mt-5 rounded-2xl border border-zinc-800 bg-zinc-950/60 p-5">
          <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-zinc-500">Texto-base</p>
          <p className="whitespace-pre-line font-display text-[15.5px] leading-relaxed text-zinc-300">{q.supportText}</p>
        </div>
      )}
      <p className="mt-5 whitespace-pre-line text-[16.5px] leading-relaxed text-zinc-100">{q.statement}</p>
      <div className="mt-6 space-y-2.5">
        {LETTERS.map((L) => (
          <OptionRow key={L} letter={L} text={q.options[L]} state={optState(q, L, pick)} disabled={q.revealed || !onChoose} onClick={() => onChoose?.(L)} />
        ))}
      </div>
    </>
  );
}

const OPT_STYLES: Record<OptState, { row: string; badge: string }> = {
  idle: { row: "border-zinc-800 bg-zinc-900/50 text-zinc-200 hover:border-zinc-600 hover:bg-zinc-900", badge: "border border-zinc-700 text-zinc-400" },
  selected: { row: "border-zinc-200 bg-zinc-100/[0.07] text-white", badge: "bg-zinc-100 text-zinc-950" },
  correct: { row: "border-emerald-500/70 bg-emerald-500/10 text-emerald-50", badge: "bg-emerald-500 text-emerald-950" },
  wrong: { row: "border-red-500/70 bg-red-500/10 text-red-50", badge: "bg-red-500 text-white" },
  dim: { row: "border-zinc-800/70 bg-zinc-950/40 text-zinc-500", badge: "border border-zinc-800 text-zinc-600" },
};

function OptionRow({ letter, text, state, disabled, onClick }: { letter: Letter; text: string; state: OptState; disabled: boolean; onClick: () => void }) {
  const s = OPT_STYLES[state];
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-pressed={state === "selected"}
      className={`flex w-full items-start gap-4 rounded-2xl border px-4 py-3.5 text-left transition disabled:cursor-default ${s.row}`}
    >
      <span className={`grid size-8 shrink-0 place-items-center rounded-xl text-sm font-bold ${s.badge}`}>{letter}</span>
      <span className="flex-1 pt-1 text-[15px] leading-relaxed">{text}</span>
      {state === "correct" && <IconCheck size={20} strokeWidth={2.4} className="mt-1 shrink-0 text-emerald-400" />}
      {state === "wrong" && <IconX size={20} strokeWidth={2.4} className="mt-1 shrink-0 text-red-400" />}
    </button>
  );
}

function Stat({ label, value, tone, icon }: { label: string; value: string; tone?: "green" | "red"; icon?: ReactNode }) {
  const color = tone === "green" ? "text-emerald-400" : tone === "red" ? "text-red-400" : "text-zinc-100";
  return (
    <div className="text-right">
      <p className="flex items-center justify-end gap-1 text-[10px] uppercase tracking-[0.18em] text-zinc-500">
        {icon}
        {label}
      </p>
      <p className={`font-display text-xl font-semibold ${color}`}>{value}</p>
    </div>
  );
}

function Legend({ cls, label }: { cls: string; label: string }) {
  return (
    <span className="flex items-center gap-2">
      <span className={`size-3 rounded ${cls}`} />
      {label}
    </span>
  );
}

function Results({ quiz, busy, error, onNewBatch }: { quiz: PublicQuiz; busy: boolean; error: string | null; onNewBatch: () => void }) {
  const [filter, setFilter] = useState<Filter>("todas");
  const qs = quiz.questions;
  const total = qs.length;
  const correct = qs.filter((q) => q.correction?.isCorrect === true).length;
  const wrong = qs.filter((q) => q.correction?.isCorrect === false).length;
  const blank = total - correct - wrong;
  const pct = total ? Math.round((correct / total) * 100) : 0;

  const byTopic = useMemo(() => {
    const m = new Map<string, { total: number; ok: number }>();
    for (const q of qs) {
      const cur = m.get(q.topic) ?? { total: 0, ok: 0 };
      cur.total += 1;
      if (q.correction?.isCorrect) cur.ok += 1;
      m.set(q.topic, cur);
    }
    return Array.from(m.entries()).sort((a, b) => b[1].total - a[1].total);
  }, [qs]);

  const verdict =
    pct >= 80 ? "Excelente! Desempenho de aprovação." : pct >= 60 ? "Bom desempenho. Revise os comentários das questões erradas." : "Continue treinando: revise a letra da lei nos comentários abaixo.";

  const filtered = qs
    .map((q, i) => ({ q, i }))
    .filter(({ q }) =>
      filter === "todas" ? true : filter === "certas" ? q.correction?.isCorrect === true : filter === "erradas" ? q.correction?.isCorrect === false : !q.userAnswer,
    );

  return (
    <div className="space-y-8">
      <section className="surface grid gap-8 rounded-3xl p-6 sm:p-8 lg:grid-cols-[auto_1fr] lg:items-center animate-fade-up">
        <div className="mx-auto grid size-44 place-items-center rounded-full p-2" style={{ background: `conic-gradient(#22c55e ${pct * 3.6}deg, #ef4444 ${pct * 3.6}deg ${((correct + wrong) / Math.max(1, total)) * 360}deg, #27272a 0deg)` }}>
          <div className="grid size-full place-items-center rounded-full bg-zinc-950">
            <div className="text-center">
              <p className="font-display text-5xl font-semibold text-zinc-50">{pct}%</p>
              <p className="text-[10px] uppercase tracking-[0.2em] text-zinc-500">de acertos</p>
            </div>
          </div>
        </div>
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-zinc-500">Resultado · {quiz.mode === "estudo" ? "Modo Estudo" : "Modo Simulado"}</p>
          <h1 className="mt-1 font-display text-3xl font-semibold text-zinc-50">{quiz.subject}</h1>
          <p className="mt-2 text-sm text-zinc-400">{verdict}</p>
          <div className="mt-5 grid grid-cols-3 gap-3 sm:max-w-md">
            <div className="rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-center">
              <p className="font-display text-2xl font-semibold text-emerald-400">{correct}</p>
              <p className="text-[10px] uppercase tracking-wider text-emerald-300/80">Certas</p>
            </div>
            <div className="rounded-2xl border border-red-500/40 bg-red-500/10 p-3 text-center">
              <p className="font-display text-2xl font-semibold text-red-400">{wrong}</p>
              <p className="text-[10px] uppercase tracking-wider text-red-300/80">Erradas</p>
            </div>
            <div className="rounded-2xl border border-zinc-700 bg-zinc-900/60 p-3 text-center">
              <p className="font-display text-2xl font-semibold text-zinc-200">{blank}</p>
              <p className="text-[10px] uppercase tracking-wider text-zinc-500">Em branco</p>
            </div>
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <button type="button" className="btn-primary" onClick={onNewBatch} disabled={busy}>
              {busy ? <IconRefresh size={16} className="animate-spin" /> : <IconSpark size={16} />} Gerar novo lote com os mesmos assuntos
            </button>
            <Link href="/" className="btn-ghost">
              Nova matéria
            </Link>
            <Link href="/historico" className="btn-ghost">
              Histórico
            </Link>
          </div>
          {error && <p className="mt-4 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-200">{error}</p>}
        </div>
      </section>

      {byTopic.length > 1 && (
        <section className="surface rounded-3xl p-6 sm:p-8">
          <h2 className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-zinc-500">
            <IconLayers size={14} /> Desempenho por assunto
          </h2>
          <div className="mt-4 space-y-3">
            {byTopic.map(([topic, s]) => {
              const p = Math.round((s.ok / s.total) * 100);
              return (
                <div key={topic}>
                  <div className="flex justify-between text-sm">
                    <span className="text-zinc-300">{topic}</span>
                    <span className="text-zinc-500">
                      {s.ok}/{s.total} · {p}%
                    </span>
                  </div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-red-500/25">
                    <div className="h-full rounded-full bg-emerald-500" style={{ width: `${p}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      <section>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-2xl font-semibold text-zinc-50">Correção comentada</h2>
          <div className="flex gap-1 rounded-xl border border-zinc-800 bg-zinc-950/60 p-1 text-xs">
            {(
              [
                ["todas", `Todas (${total})`],
                ["erradas", `Erradas (${wrong})`],
                ["certas", `Certas (${correct})`],
                ["branco", `Em branco (${blank})`],
              ] as const
            ).map(([k, label]) => (
              <button
                key={k}
                type="button"
                onClick={() => setFilter(k)}
                className={`rounded-lg px-3 py-1.5 transition ${filter === k ? "bg-zinc-100 font-semibold text-zinc-950" : "text-zinc-400 hover:text-zinc-100"}`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-5 space-y-6">
          {filtered.map(({ q, i }) => (
            <article key={q.id} className="surface rounded-3xl p-6 sm:p-8">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span
                  className={`rounded-lg px-2.5 py-1 font-bold ${
                    q.correction?.isCorrect ? "bg-emerald-500 text-emerald-950" : q.correction?.isCorrect === false ? "bg-red-500 text-white" : "bg-zinc-700 text-zinc-100"
                  }`}
                >
                  Questão {i + 1}
                </span>
                <span className="rounded-full border border-zinc-700 px-2.5 py-1 text-zinc-300">{q.topic}</span>
                <span className="ml-auto text-[11px] text-zinc-600">{originLabel(q)}</span>
              </div>
              <QuestionBody q={q} />
              <Commentary q={q} />
            </article>
          ))}
          {!filtered.length && <p className="rounded-2xl border border-zinc-800 p-6 text-center text-sm text-zinc-500">Nenhuma questão neste filtro.</p>}
        </div>
      </section>
    </div>
  );
}
