import { sql } from "drizzle-orm";
import { db } from "./index";

/**
 * Garante (de forma idempotente) que as tabelas existam, mesmo que o
 * `drizzle-kit push` não tenha sido executado no ambiente. A DDL espelha
 * exatamente o que o drizzle-kit gera a partir de `schema.ts`.
 */
const DDL = `
CREATE TABLE IF NOT EXISTS "researches" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "subject" text NOT NULL,
  "subject_key" text NOT NULL,
  "cargo" text,
  "topics" jsonb NOT NULL,
  "sources" jsonb NOT NULL,
  "summary" text,
  "style_tips" jsonb,
  "search_log" jsonb,
  "method" text NOT NULL,
  "engine" text NOT NULL,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL
);
CREATE INDEX IF NOT EXISTS "researches_subject_key_idx" ON "researches" USING btree ("subject_key");
CREATE TABLE IF NOT EXISTS "quizzes" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "subject" text NOT NULL,
  "cargo" text,
  "research_id" uuid,
  "topics" jsonb NOT NULL,
  "plan" jsonb NOT NULL,
  "question_count" integer NOT NULL,
  "mode" text NOT NULL,
  "status" text DEFAULT 'generating' NOT NULL,
  "answered_count" integer DEFAULT 0 NOT NULL,
  "correct_count" integer DEFAULT 0 NOT NULL,
  "engine" text,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "finished_at" timestamp with time zone
);
CREATE TABLE IF NOT EXISTS "questions" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "quiz_id" uuid NOT NULL,
  "position" integer NOT NULL,
  "topic" text NOT NULL,
  "support_text" text,
  "statement" text NOT NULL,
  "options" jsonb NOT NULL,
  "correct" text NOT NULL,
  "summary" text NOT NULL,
  "legal_basis" text,
  "law_text" text,
  "law_url" text,
  "analysis" jsonb NOT NULL,
  "tip" text,
  "difficulty" text,
  "origin" text NOT NULL,
  "engine" text,
  "bank_id" text,
  "user_answer" text,
  "is_correct" boolean,
  "answered_at" timestamp with time zone,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "questions_quiz_id_quizzes_id_fk" FOREIGN KEY ("quiz_id") REFERENCES "public"."quizzes"("id") ON DELETE cascade ON UPDATE no action
);
CREATE UNIQUE INDEX IF NOT EXISTS "questions_quiz_position_idx" ON "questions" USING btree ("quiz_id","position");
`;

let ready: Promise<void> | null = null;

export function ensureSchema(): Promise<void> {
  if (!ready) {
    ready = db
      .execute(sql.raw(DDL))
      .then(() => undefined)
      .catch((err) => {
        ready = null;
        throw err;
      });
  }
  return ready;
}
