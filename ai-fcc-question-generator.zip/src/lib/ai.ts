import { extractJson, sleep } from "./text";

export type ProviderId = "openai" | "gemini" | "anthropic" | "groq" | "openrouter" | "deepseek" | "free";

export interface ProviderInfo {
  id: ProviderId;
  label: string;
  model: string;
  premium: boolean;
}

const FALLBACK_MODELS: Record<ProviderId, string[]> = {
  openai: ["gpt-4.1-mini", "gpt-5-mini", "gpt-4o-mini"],
  gemini: ["gemini-2.5-flash", "gemini-flash-latest", "gemini-2.0-flash"],
  anthropic: ["claude-sonnet-4-5", "claude-haiku-4-5", "claude-3-5-haiku-latest"],
  groq: ["llama-3.3-70b-versatile", "openai/gpt-oss-120b"],
  openrouter: ["openai/gpt-4.1-mini", "google/gemini-2.5-flash"],
  deepseek: ["deepseek-chat"],
  free: ["openai"],
};

function geminiKey(): string {
  return process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || process.env.GOOGLE_GENERATIVE_AI_API_KEY || "";
}

export function listProviders(): ProviderInfo[] {
  const list: ProviderInfo[] = [];
  if (process.env.OPENAI_API_KEY)
    list.push({ id: "openai", label: "OpenAI", model: process.env.OPENAI_MODEL || FALLBACK_MODELS.openai[0], premium: true });
  if (geminiKey())
    list.push({ id: "gemini", label: "Google Gemini", model: process.env.GEMINI_MODEL || FALLBACK_MODELS.gemini[0], premium: true });
  if (process.env.ANTHROPIC_API_KEY)
    list.push({ id: "anthropic", label: "Anthropic Claude", model: process.env.ANTHROPIC_MODEL || FALLBACK_MODELS.anthropic[0], premium: true });
  if (process.env.GROQ_API_KEY)
    list.push({ id: "groq", label: "Groq", model: process.env.GROQ_MODEL || FALLBACK_MODELS.groq[0], premium: true });
  if (process.env.OPENROUTER_API_KEY)
    list.push({ id: "openrouter", label: "OpenRouter", model: process.env.OPENROUTER_MODEL || FALLBACK_MODELS.openrouter[0], premium: true });
  if (process.env.DEEPSEEK_API_KEY)
    list.push({ id: "deepseek", label: "DeepSeek", model: process.env.DEEPSEEK_MODEL || FALLBACK_MODELS.deepseek[0], premium: true });
  return list;
}

export function getProvider(): ProviderInfo {
  const list = listProviders();
  const forced = (process.env.AI_PROVIDER || "").toLowerCase().trim();
  if (forced) {
    const f = list.find((p) => p.id === forced);
    if (f) return f;
  }
  if (list.length) return list[0];
  return { id: "free", label: "IA gratuita (Pollinations)", model: "openai", premium: false };
}

export function freeAiEnabled(): boolean {
  return process.env.DISABLE_FREE_AI !== "1";
}

export class AiError extends Error {
  status?: number;
  retryable: boolean;
  constructor(message: string, status?: number, retryable = false) {
    super(message);
    this.status = status;
    this.retryable = retryable;
  }
}

async function postJson(
  url: string,
  headers: Record<string, string>,
  body: unknown,
  timeoutMs: number,
): Promise<Record<string, unknown>> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...headers },
      body: JSON.stringify(body),
      signal: ctrl.signal,
      cache: "no-store",
    });
    const text = await res.text();
    if (!res.ok) {
      throw new AiError(`HTTP ${res.status}: ${text.slice(0, 300)}`, res.status, res.status === 429 || res.status >= 500);
    }
    try {
      return JSON.parse(text) as Record<string, unknown>;
    } catch {
      throw new AiError("Resposta inválida do provedor de IA", res.status, true);
    }
  } catch (err) {
    if ((err as Error).name === "AbortError") throw new AiError("Tempo limite excedido na chamada à IA", 408, true);
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

export interface ChatOptions {
  system: string;
  user: string;
  temperature?: number;
  maxTokens?: number;
  timeoutMs?: number;
}

type AnyRec = Record<string, unknown>;

async function callOpenAICompatible(p: ProviderInfo, model: string, o: ChatOptions): Promise<string> {
  let url = "https://text.pollinations.ai/openai";
  let key = "";
  if (p.id === "openai") {
    url = `${(process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "")}/chat/completions`;
    key = process.env.OPENAI_API_KEY || "";
  } else if (p.id === "groq") {
    url = "https://api.groq.com/openai/v1/chat/completions";
    key = process.env.GROQ_API_KEY || "";
  } else if (p.id === "openrouter") {
    url = "https://openrouter.ai/api/v1/chat/completions";
    key = process.env.OPENROUTER_API_KEY || "";
  } else if (p.id === "deepseek") {
    url = "https://api.deepseek.com/chat/completions";
    key = process.env.DEEPSEEK_API_KEY || "";
  }
  const bare = model.replace(/^openai\//, "");
  const reasoning = /^(gpt-5|o\d)/i.test(bare);
  const body: AnyRec = {
    model,
    messages: [
      { role: "system", content: o.system },
      { role: "user", content: o.user },
    ],
    response_format: { type: "json_object" },
  };
  if (p.id !== "free" && !reasoning) body.temperature = o.temperature ?? 0.7;
  if (p.id === "openai") {
    body.max_completion_tokens = o.maxTokens ?? 8000;
    if (reasoning) body.reasoning_effort = "low";
  } else if (p.id === "free") {
    // Modelo gratuito (GPT-OSS): raciocínio curto evita respostas vazias por esgotamento de tokens.
    body.max_tokens = Math.max(4000, o.maxTokens ?? 6000);
    body.reasoning_effort = "low";
  } else {
    body.max_tokens = o.maxTokens ?? 8000;
  }
  const headers: Record<string, string> = key ? { Authorization: `Bearer ${key}` } : {};
  if (p.id === "openrouter") headers["X-Title"] = "Questoes FCC Premium";
  const data = await postJson(url, headers, body, o.timeoutMs ?? 100_000);
  const choices = data.choices as Array<{ message?: { content?: unknown } }> | undefined;
  const content = choices?.[0]?.message?.content;
  if (typeof content !== "string" || !content.trim()) throw new AiError("Resposta vazia da IA", undefined, true);
  return content;
}

async function callGemini(model: string, o: ChatOptions): Promise<string> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  const body = {
    systemInstruction: { parts: [{ text: o.system }] },
    contents: [{ role: "user", parts: [{ text: o.user }] }],
    generationConfig: {
      temperature: o.temperature ?? 0.7,
      maxOutputTokens: Math.min(65536, (o.maxTokens ?? 8000) * 3),
      responseMimeType: "application/json",
    },
  };
  const data = await postJson(url, { "x-goog-api-key": geminiKey() }, body, o.timeoutMs ?? 100_000);
  const candidates = data.candidates as Array<{ content?: { parts?: Array<{ text?: string; thought?: boolean }> }; finishReason?: string }> | undefined;
  const parts = candidates?.[0]?.content?.parts ?? [];
  const text = parts.map((x) => (x.thought ? "" : x.text ?? "")).join("");
  if (!text.trim()) throw new AiError(`Resposta vazia do Gemini (${candidates?.[0]?.finishReason ?? "sem motivo"})`, undefined, true);
  return text;
}

async function callAnthropic(model: string, o: ChatOptions): Promise<string> {
  const data = await postJson(
    "https://api.anthropic.com/v1/messages",
    { "x-api-key": process.env.ANTHROPIC_API_KEY || "", "anthropic-version": "2023-06-01" },
    {
      model,
      max_tokens: o.maxTokens ?? 8000,
      temperature: o.temperature ?? 0.7,
      system: o.system,
      messages: [{ role: "user", content: o.user }],
    },
    o.timeoutMs ?? 120_000,
  );
  const content = data.content as Array<{ type?: string; text?: string }> | undefined;
  const text = (content ?? []).filter((c) => c.type === "text").map((c) => c.text ?? "").join("");
  if (!text.trim()) throw new AiError("Resposta vazia do Claude", undefined, true);
  return text;
}

async function callOnce(p: ProviderInfo, model: string, o: ChatOptions): Promise<string> {
  if (p.id === "gemini") return callGemini(model, o);
  if (p.id === "anthropic") return callAnthropic(model, o);
  return callOpenAICompatible(p, model, o);
}

async function callWithModelFallback(p: ProviderInfo, o: ChatOptions): Promise<{ text: string; model: string }> {
  const models = Array.from(new Set([p.model, ...FALLBACK_MODELS[p.id]]));
  let lastErr: unknown;
  for (const m of models) {
    try {
      return { text: await callOnce(p, m, o), model: m };
    } catch (err) {
      lastErr = err;
      const e = err as AiError;
      const modelProblem = e.status === 404 || (e.status === 400 && /model/i.test(e.message));
      if (!modelProblem) throw err;
    }
  }
  throw lastErr;
}

/** A IA gratuita aceita apenas 1 requisição simultânea por IP: serializamos as chamadas. */
let freeQueue: Promise<unknown> = Promise.resolve();
function runExclusive<T>(fn: () => Promise<T>): Promise<T> {
  const run = freeQueue.then(fn, fn);
  freeQueue = run.then(
    () => sleep(300),
    () => sleep(300),
  );
  return run;
}

export async function chatJSON<T>(
  o: ChatOptions,
  provider: ProviderInfo = getProvider(),
): Promise<{ data: T; provider: ProviderInfo; model: string }> {
  const p = provider;
  if (p.id === "free" && !freeAiEnabled()) throw new AiError("IA gratuita desativada", 503, false);
  const attempts = p.id === "free" ? 3 : 2;
  let lastErr: unknown;
  for (let i = 0; i < attempts; i++) {
    try {
      const exec = () => callWithModelFallback(p, o);
      const { text, model } = p.id === "free" ? await runExclusive(exec) : await exec();
      const data = extractJson<T>(text);
      if (!data || typeof data !== "object") throw new AiError("A IA não retornou JSON válido", undefined, true);
      return { data, provider: p, model };
    } catch (err) {
      lastErr = err;
      if (err instanceof AiError && !err.retryable) break;
      await sleep(p.id === "free" ? 2500 * (i + 1) : 1200);
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error("Falha na chamada à IA");
}
