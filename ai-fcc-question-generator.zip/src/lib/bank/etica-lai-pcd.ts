import { mk } from "./make";

export const ETICA_LAI_PCD = [
  /* ============================ ÉTICA (DECRETO Nº 1.171/1994) ============================ */
  mk({
    id: "etica-censura-01",
    subject: "etica",
    topic: "Comissões de Ética e pena de censura",
    statement:
      "De acordo com o Código de Ética Profissional do Servidor Público Civil do Poder Executivo Federal (Decreto nº 1.171/1994), a pena aplicável ao servidor público pela Comissão de Ética é a de",
    options: ["advertência.", "suspensão.", "censura.", "demissão.", "multa."],
    correct: "C",
    summary:
      "A única pena que a Comissão de Ética pode aplicar é a de censura, cuja fundamentação constará do parecer assinado por todos os seus integrantes, com ciência do faltoso. Advertência, suspensão e demissão são penalidades disciplinares da Lei nº 8.112/1990, aplicadas pela autoridade competente após sindicância ou PAD.",
    legalBasis: "Decreto nº 1.171/1994, Anexo, inciso XXII",
    lawText:
      "XXII - A pena aplicável ao servidor público pela Comissão de Ética é a de censura e sua fundamentação constará do respectivo parecer, assinado por todos os seus integrantes, com ciência do faltoso.",
    analysis: [
      "Errada. Advertência é penalidade disciplinar da Lei nº 8.112/1990 (art. 127, I).",
      "Errada. Suspensão é penalidade disciplinar da Lei nº 8.112/1990 (art. 127, II).",
      "Correta. Censura é a única pena aplicável pela Comissão de Ética.",
      "Errada. Demissão é penalidade disciplinar aplicada mediante PAD.",
      "Errada. O Código de Ética não prevê multa.",
    ],
    tip: "Comissão de Ética = CENSURA, e nada mais. A FCC tenta confundir com as penalidades da Lei nº 8.112/1990.",
    difficulty: "Fácil",
  }),
  mk({
    id: "etica-moralidade-01",
    subject: "etica",
    topic: "Decreto nº 1.171/1994: regras deontológicas",
    statement: "Segundo o Decreto nº 1.171/1994, a moralidade da Administração Pública",
    options: [
      "limita-se à distinção entre o bem e o mal, sendo irrelevante a finalidade do ato.",
      "não se limita à distinção entre o bem e o mal, devendo ser acrescida da ideia de que o fim é sempre o bem comum.",
      "restringe-se à observância da legalidade estrita pelo servidor, dispensada a análise da finalidade.",
      "aplica-se somente ao exercício do cargo, não alcançando a vida privada do servidor.",
      "é aferida exclusivamente pela Comissão de Ética, que decide sobre a validade dos atos administrativos.",
    ],
    correct: "B",
    summary:
      "Para o Código de Ética, a moralidade administrativa vai além da distinção entre o bem e o mal: deve-se acrescentar a ideia de que o fim é sempre o bem comum. É o equilíbrio entre legalidade e finalidade que consolida a moralidade do ato administrativo. O Código também afirma que a função pública se integra à vida particular do servidor.",
    legalBasis: "Decreto nº 1.171/1994, Anexo, regras deontológicas III e VI",
    lawText:
      "III - A moralidade da Administração Pública não se limita à distinção entre o bem e o mal, devendo ser acrescida da idéia de que o fim é sempre o bem comum. O equilíbrio entre a legalidade e a finalidade, na conduta do servidor público, é que poderá consolidar a moralidade do ato administrativo.\nVI - A função pública deve ser tida como exercício profissional e, portanto, se integra na vida particular de cada servidor público. Assim, os fatos e atos verificados na conduta do dia-a-dia em sua vida privada poderão acrescer ou diminuir o seu bom conceito na vida funcional.",
    analysis: [
      "Errada. Contraria expressamente a regra III.",
      "Correta. Literalidade da regra deontológica III.",
      "Errada. A moralidade decorre do equilíbrio entre legalidade e finalidade.",
      "Errada. A função pública se integra na vida particular do servidor (regra VI).",
      "Errada. A Comissão de Ética não decide sobre a validade de atos administrativos.",
    ],
    tip: "A FCC costuma trocar \"não se limita\" por \"limita-se\" e \"bem comum\" por \"interesse do servidor\" ou \"interesse da chefia\".",
  }),
  mk({
    id: "etica-vedacoes-01",
    subject: "etica",
    topic: "Vedações ao servidor público",
    statement: "Nos termos do Decreto nº 1.171/1994, é vedado ao servidor público",
    options: [
      "exercer suas atribuições com rapidez, perfeição e rendimento.",
      "ser assíduo e frequente ao serviço.",
      "usar do cargo ou função, facilidades, amizades, tempo, posição e influências, para obter qualquer favorecimento, para si ou para outrem.",
      "facilitar a fiscalização de todos os atos ou serviços por quem de direito.",
      "manter-se atualizado com as instruções, as normas de serviço e a legislação pertinentes ao órgão onde exerce suas funções.",
    ],
    correct: "C",
    summary:
      "O inciso XV do Código de Ética lista as vedações ao servidor, e a primeira delas é o uso do cargo ou função, facilidades, amizades, tempo, posição e influências para obter qualquer favorecimento, para si ou para outrem. As demais alternativas reproduzem deveres fundamentais do servidor, previstos no inciso XIV.",
    legalBasis: "Decreto nº 1.171/1994, Anexo, incisos XIV e XV",
    lawText:
      "XV - É vedado ao servidor público;\na) o uso do cargo ou função, facilidades, amizades, tempo, posição e influências, para obter qualquer favorecimento, para si ou para outrem;",
    analysis: [
      "Errada. É dever fundamental do servidor (inciso XIV).",
      "Errada. Ser assíduo e frequente ao serviço é dever (inciso XIV).",
      "Correta. Vedação prevista no inciso XV, a.",
      "Errada. Facilitar a fiscalização é dever (inciso XIV).",
      "Errada. Manter-se atualizado é dever (inciso XIV).",
    ],
    tip: "Inciso XIV = deveres; inciso XV = vedações. A FCC mistura os dois róis nas alternativas.",
    difficulty: "Fácil",
  }),
  mk({
    id: "etica-primados-01",
    subject: "etica",
    topic: "Decreto nº 1.171/1994: regras deontológicas",
    statement:
      "De acordo com o Decreto nº 1.171/1994, são primados maiores que devem nortear o servidor público, seja no exercício do cargo ou função, ou fora dele:",
    options: [
      "a dignidade, o decoro, o zelo, a eficácia e a consciência dos princípios morais.",
      "a hierarquia, a disciplina, a obediência e a lealdade às chefias.",
      "a produtividade, a pontualidade e a economicidade.",
      "a legalidade estrita, a impessoalidade e a publicidade dos atos.",
      "a neutralidade política, o sigilo e a discrição.",
    ],
    correct: "A",
    summary:
      "A primeira regra deontológica do Código de Ética elenca os primados maiores que devem nortear o servidor, dentro e fora do exercício do cargo: dignidade, decoro, zelo, eficácia e consciência dos princípios morais. Seus atos devem se direcionar à preservação da honra e da tradição dos serviços públicos.",
    legalBasis: "Decreto nº 1.171/1994, Anexo, regra deontológica I",
    lawText:
      "I - A dignidade, o decoro, o zelo, a eficácia e a consciência dos princípios morais são primados maiores que devem nortear o servidor público, seja no exercício do cargo ou função, ou fora dele, já que refletirá o exercício da vocação do próprio poder estatal. Seus atos, comportamentos e atitudes serão direcionados para a preservação da honra e da tradição dos serviços públicos.",
    analysis: [
      "Correta. Literalidade da regra deontológica I.",
      "Errada. Esses valores não constam da regra I.",
      "Errada. Esses valores não constam da regra I.",
      "Errada. Remete a princípios do art. 37 da CF, e não aos primados do Código de Ética.",
      "Errada. Esses valores não constam da regra I.",
    ],
    tip: "Memorize a sequência \"dignidade, decoro, zelo, eficácia e consciência dos princípios morais\" — a FCC costuma cobrá-la literalmente.",
    difficulty: "Fácil",
  }),

  /* ======================= LEI DE ACESSO À INFORMAÇÃO (12.527/2011) ======================= */
  mk({
    id: "lai-prazos-01",
    subject: "lai",
    topic: "Procedimento de acesso e prazos de resposta",
    statement:
      "De acordo com a Lei nº 12.527/2011, não sendo possível conceder o acesso imediato à informação disponível, o órgão ou entidade que receber o pedido deverá atendê-lo em prazo não superior a",
    options: [
      "20 dias, prorrogável por mais 10 dias, mediante justificativa expressa, da qual será cientificado o requerente.",
      "10 dias, prorrogável por mais 5 dias, mediante justificativa expressa.",
      "30 dias, improrrogável.",
      "15 dias, prorrogável por igual período, independentemente de justificativa.",
      "20 dias, prorrogável por mais 20 dias, a critério da autoridade.",
    ],
    correct: "A",
    summary:
      "A regra é o acesso imediato à informação disponível. Não sendo possível, o órgão tem até 20 dias para comunicar data, local e modo da consulta, indicar as razões da recusa ou informar que não possui a informação. Esse prazo pode ser prorrogado por mais 10 dias, mediante justificativa expressa comunicada ao requerente.",
    legalBasis: "Lei nº 12.527/2011, art. 11, §§ 1º e 2º",
    lawText:
      "§ 1º Não sendo possível conceder o acesso imediato, na forma disposta no caput, o órgão ou entidade que receber o pedido deverá, em prazo não superior a 20 (vinte) dias:\nI - comunicar a data, local e modo para se realizar a consulta, efetuar a reprodução ou obter a certidão;\nII - indicar as razões de fato ou de direito da recusa, total ou parcial, do acesso pretendido; ou\nIII - comunicar que não possui a informação, indicar, se for do seu conhecimento, o órgão ou a entidade que a detém, ou, ainda, remeter o requerimento a esse órgão ou entidade, cientificando o interessado da remessa de seu pedido de informação.\n§ 2º O prazo referido no § 1º poderá ser prorrogado por mais 10 (dez) dias, mediante justificativa expressa, da qual será cientificado o requerente.",
    analysis: [
      "Correta. 20 dias, prorrogáveis por mais 10, com justificativa expressa.",
      "Errada. Os prazos estão incorretos.",
      "Errada. O prazo é de 20 dias e admite prorrogação.",
      "Errada. O prazo é de 20 dias, e a prorrogação exige justificativa expressa.",
      "Errada. A prorrogação é de 10 dias e depende de justificativa expressa.",
    ],
    tip: "LAI: 20 + 10 dias para responder; 10 dias para recorrer; 5 dias para a autoridade superior se manifestar sobre o recurso.",
    difficulty: "Fácil",
  }),
  mk({
    id: "lai-classificacao-01",
    subject: "lai",
    topic: "Classificação da informação e prazos de sigilo",
    statement:
      "Nos termos da Lei nº 12.527/2011, os prazos máximos de restrição de acesso à informação classificada como ultrassecreta, secreta e reservada são, respectivamente, de",
    options: ["25 anos, 15 anos e 5 anos.", "30 anos, 20 anos e 10 anos.", "25 anos, 10 anos e 5 anos.", "50 anos, 25 anos e 15 anos.", "15 anos, 10 anos e 5 anos."],
    correct: "A",
    summary:
      "A LAI prevê três graus de sigilo, com prazos máximos contados da data de produção da informação: ultrassecreta (25 anos), secreta (15 anos) e reservada (5 anos). Já as informações pessoais relativas à intimidade, vida privada, honra e imagem têm acesso restrito pelo prazo máximo de 100 anos, independentemente de classificação.",
    legalBasis: "Lei nº 12.527/2011, art. 24, § 1º",
    lawText:
      "§ 1º Os prazos máximos de restrição de acesso à informação, conforme a classificação prevista no caput, vigoram a partir da data de sua produção e são os seguintes:\nI - ultrassecreta: 25 (vinte e cinco) anos;\nII - secreta: 15 (quinze) anos; e\nIII - reservada: 5 (cinco) anos.",
    analysis: [
      "Correta. 25, 15 e 5 anos.",
      "Errada. Os prazos estão incorretos.",
      "Errada. O prazo da informação secreta é de 15 anos.",
      "Errada. Os prazos estão incorretos.",
      "Errada. A ultrassecreta tem prazo de 25 anos.",
    ],
    tip: "Sequência 25-15-5. Não existe mais a categoria \"confidencial\" na LAI — pegadinha frequente.",
    difficulty: "Fácil",
  }),
  mk({
    id: "lai-pedido-01",
    subject: "lai",
    topic: "Transparência ativa e passiva",
    statement: "Carla apresentou pedido de acesso a informações de interesse público a órgão federal. Conforme a Lei nº 12.527/2011,",
    options: [
      "o pedido deverá conter a identificação do requerente e a especificação da informação requerida, sendo vedadas quaisquer exigências relativas aos motivos determinantes da solicitação.",
      "Carla deverá expor os motivos da solicitação, sob pena de indeferimento.",
      "o serviço de busca e fornecimento da informação será sempre cobrado, conforme tabela do órgão.",
      "o pedido somente poderá ser apresentado pessoalmente, vedado o uso da internet.",
      "em caso de indeferimento, não caberá recurso administrativo, restando apenas a via judicial.",
    ],
    correct: "A",
    summary:
      "Qualquer interessado pode pedir informações por qualquer meio legítimo, bastando identificar-se e especificar a informação requerida. É proibido exigir os motivos do pedido de informações de interesse público. O serviço de busca e fornecimento é, em regra, gratuito, e contra a negativa de acesso cabe recurso no prazo de 10 dias.",
    legalBasis: "Lei nº 12.527/2011, art. 10, caput e § 3º",
    lawText:
      "Art. 10. Qualquer interessado poderá apresentar pedido de acesso a informações aos órgãos e entidades referidos no art. 1º desta Lei, por qualquer meio legítimo, devendo o pedido conter a identificação do requerente e a especificação da informação requerida.\n§ 3º São vedadas quaisquer exigências relativas aos motivos determinantes da solicitação de informações de interesse público.",
    analysis: [
      "Correta. Art. 10, caput e § 3º.",
      "Errada. É vedado exigir os motivos da solicitação.",
      "Errada. O serviço é gratuito, salvo o custo de reprodução de documentos (art. 12).",
      "Errada. O pedido pode ser feito por qualquer meio legítimo, e os órgãos devem permitir o envio pela internet (art. 10, § 2º).",
      "Errada. Cabe recurso no prazo de 10 dias (art. 15).",
    ],
    tip: "A FCC adora afirmar que o requerente precisa justificar o pedido. Na LAI, a motivação NÃO pode ser exigida.",
  }),

  /* =================== ESTATUTO DA PESSOA COM DEFICIÊNCIA (13.146/2015) =================== */
  mk({
    id: "pcd-conceito-01",
    subject: "pcd",
    topic: "Conceitos: pessoa com deficiência, barreiras e acessibilidade",
    statement:
      "Nos termos da Lei nº 13.146/2015 (Estatuto da Pessoa com Deficiência), considera-se pessoa com deficiência aquela que tem impedimento de",
    options: [
      "longo prazo de natureza física, mental, intelectual ou sensorial, o qual, em interação com uma ou mais barreiras, pode obstruir sua participação plena e efetiva na sociedade em igualdade de condições com as demais pessoas.",
      "qualquer duração, de natureza exclusivamente física, que a impeça de exercer atividade laboral.",
      "curto ou longo prazo, que a torne absolutamente incapaz para os atos da vida civil.",
      "natureza física ou sensorial, desde que congênita e comprovada por laudo médico oficial.",
      "longo prazo de natureza física, apenas, que dependa de tecnologia assistiva para a locomoção.",
    ],
    correct: "A",
    summary:
      "O Estatuto adota o modelo biopsicossocial: a deficiência resulta da interação entre um impedimento de longo prazo (físico, mental, intelectual ou sensorial) e as barreiras existentes, que podem obstruir a participação plena e efetiva na sociedade. A deficiência não afeta a plena capacidade civil da pessoa.",
    legalBasis: "Lei nº 13.146/2015, art. 2º",
    lawText:
      "Art. 2º Considera-se pessoa com deficiência aquela que tem impedimento de longo prazo de natureza física, mental, intelectual ou sensorial, o qual, em interação com uma ou mais barreiras, pode obstruir sua participação plena e efetiva na sociedade em igualdade de condições com as demais pessoas.",
    analysis: [
      "Correta. Literalidade do art. 2º.",
      "Errada. O impedimento é de longo prazo e não apenas físico, e o conceito não se vincula ao trabalho.",
      "Errada. A deficiência não afeta a plena capacidade civil (art. 6º).",
      "Errada. A lei não exige que o impedimento seja congênito.",
      "Errada. O impedimento pode ser físico, mental, intelectual ou sensorial.",
    ],
    tip: "Palavras-chave: \"longo prazo\" + \"física, mental, intelectual ou sensorial\" + \"interação com barreiras\".",
    difficulty: "Fácil",
  }),
  mk({
    id: "pcd-barreiras-01",
    subject: "pcd",
    topic: "Conceitos: pessoa com deficiência, barreiras e acessibilidade",
    statement:
      "Segundo a Lei nº 13.146/2015, as atitudes ou comportamentos que impeçam ou prejudiquem a participação social da pessoa com deficiência em igualdade de condições e oportunidades com as demais pessoas são denominados barreiras",
    options: ["urbanísticas.", "arquitetônicas.", "atitudinais.", "tecnológicas.", "nas comunicações e na informação."],
    correct: "C",
    summary:
      "O Estatuto classifica as barreiras em urbanísticas, arquitetônicas, nos transportes, nas comunicações e na informação, atitudinais e tecnológicas. As barreiras atitudinais são atitudes ou comportamentos que impedem ou prejudicam a participação social da pessoa com deficiência em igualdade de condições.",
    legalBasis: "Lei nº 13.146/2015, art. 3º, IV",
    lawText:
      "IV - barreiras: qualquer entrave, obstáculo, atitude ou comportamento que limite ou impeça a participação social da pessoa, bem como o gozo, a fruição e o exercício de seus direitos à acessibilidade, à liberdade de movimento e de expressão, à comunicação, ao acesso à informação, à compreensão, à circulação com segurança, entre outros, classificadas em:\na) barreiras urbanísticas: as existentes nas vias e nos espaços públicos e privados abertos ao público ou de uso coletivo;\nb) barreiras arquitetônicas: as existentes nos edifícios públicos e privados;\nc) barreiras nos transportes: as existentes nos sistemas e meios de transportes;\nd) barreiras nas comunicações e na informação: qualquer entrave, obstáculo, atitude ou comportamento que dificulte ou impossibilite a expressão ou o recebimento de mensagens e de informações por intermédio de sistemas de comunicação e de tecnologia da informação;\ne) barreiras atitudinais: atitudes ou comportamentos que impeçam ou prejudiquem a participação social da pessoa com deficiência em igualdade de condições e oportunidades com as demais pessoas;\nf) barreiras tecnológicas: as que dificultam ou impedem o acesso da pessoa com deficiência às tecnologias;",
    analysis: [
      "Errada. Barreiras urbanísticas existem nas vias e espaços públicos e privados abertos ao público.",
      "Errada. Barreiras arquitetônicas existem nos edifícios públicos e privados.",
      "Correta. Atitudes ou comportamentos = barreiras atitudinais (art. 3º, IV, e).",
      "Errada. Barreiras tecnológicas dificultam ou impedem o acesso às tecnologias.",
      "Errada. Referem-se à expressão ou ao recebimento de mensagens e informações por sistemas de comunicação.",
    ],
    tip: "Urbanísticas = vias e espaços; arquitetônicas = edifícios; atitudinais = comportamentos.",
    difficulty: "Fácil",
  }),
  mk({
    id: "pcd-curatela-01",
    subject: "pcd",
    topic: "Curatela e tomada de decisão apoiada",
    statement: "De acordo com a Lei nº 13.146/2015, a curatela da pessoa com deficiência",
    options: [
      "afetará tão somente os atos relacionados aos direitos de natureza patrimonial e negocial, não alcançando o direito ao matrimônio e ao voto.",
      "é medida ordinária e definitiva, aplicável a toda pessoa com deficiência intelectual.",
      "alcança o direito ao próprio corpo, à sexualidade e ao matrimônio.",
      "torna a pessoa com deficiência absolutamente incapaz para os atos da vida civil.",
      "impede o exercício do direito ao trabalho e à educação.",
    ],
    correct: "A",
    summary:
      "A curatela da pessoa com deficiência é medida protetiva extraordinária, proporcional às necessidades de cada caso e pelo menor tempo possível. Ela afeta apenas os atos de natureza patrimonial e negocial e não alcança os direitos ao próprio corpo, à sexualidade, ao matrimônio, à privacidade, à educação, à saúde, ao trabalho e ao voto.",
    legalBasis: "Lei nº 13.146/2015, arts. 84, § 3º, e 85, caput e § 1º",
    lawText:
      "Art. 84, § 3º A definição de curatela de pessoa com deficiência constitui medida protetiva extraordinária, proporcional às necessidades e às circunstâncias de cada caso, e durará o menor tempo possível.\nArt. 85. A curatela afetará tão somente os atos relacionados aos direitos de natureza patrimonial e negocial.\n§ 1º A definição da curatela não alcança o direito ao próprio corpo, à sexualidade, ao matrimônio, à privacidade, à educação, à saúde, ao trabalho e ao voto.",
    analysis: [
      "Correta. Art. 85, caput e § 1º.",
      "Errada. A curatela é medida extraordinária e deve durar o menor tempo possível (art. 84, § 3º).",
      "Errada. Esses direitos estão expressamente excluídos da curatela (art. 85, § 1º).",
      "Errada. A deficiência não afeta a plena capacidade civil (art. 6º).",
      "Errada. A curatela não alcança os direitos ao trabalho e à educação.",
    ],
    tip: "Curatela = só patrimônio e negócios. A tomada de decisão apoiada (art. 1.783-A do Código Civil) exige ao menos dois apoiadores escolhidos pela própria pessoa.",
  }),
];
