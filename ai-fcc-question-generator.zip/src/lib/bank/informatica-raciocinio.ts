import { mk } from "./make";

export const INFORMATICA_RACIOCINIO = [
  /* ================================ INFORMÁTICA ================================ */
  mk({
    id: "inf-excel-01",
    subject: "informatica",
    topic: "Planilhas (Excel/Calc): fórmulas, funções e referências",
    statement:
      "Um Técnico digitou, na célula C1 de uma planilha do Microsoft Excel 2016, em português, a fórmula =A1*$B$1 e, em seguida, copiou essa célula e colou-a na célula C3. A fórmula presente na célula C3 será",
    options: ["=A3*$B$1", "=A3*$B$3", "=A1*$B$1", "=C3*$B$1", "=A3*B3"],
    correct: "A",
    summary:
      "Ao copiar uma fórmula, as referências relativas se ajustam ao deslocamento, enquanto as absolutas (com $ antes da coluna e da linha) permanecem fixas. De C1 para C3 há deslocamento de 2 linhas e 0 colunas: A1 torna-se A3, e $B$1 continua $B$1.",
    legalBasis: "Conceito-chave: referências relativas, absolutas e mistas",
    lawText:
      "Referência relativa (A1) ajusta linha e coluna ao ser copiada; absoluta ($A$1) não se altera; mista ($A1 ou A$1) fixa apenas a parte precedida por $.",
    analysis: [
      "Correta. A1 desloca 2 linhas (A3) e $B$1 permanece fixa.",
      "Errada. $B$1 é absoluta e não muda para $B$3.",
      "Errada. A1 é relativa e se ajusta ao deslocamento.",
      "Errada. Não houve deslocamento de colunas, e a coluna A permanece A.",
      "Errada. Os cifrões não desaparecem na cópia.",
    ],
    tip: "A tecla F4 alterna entre os tipos de referência: A1 → $A$1 → A$1 → $A1.",
    difficulty: "Fácil",
  }),
  mk({
    id: "inf-seguranca-01",
    subject: "informatica",
    topic: "Segurança da informação: malwares, golpes e backup",
    statement:
      "Um usuário percebeu que os arquivos de seu computador foram criptografados e recebeu uma mensagem exigindo pagamento em criptomoeda para a liberação do acesso. Esse tipo de código malicioso é denominado",
    options: ["spyware.", "worm.", "ransomware.", "keylogger.", "adware."],
    correct: "C",
    summary:
      "Ransomware é o código malicioso que torna inacessíveis os dados de um equipamento, geralmente por meio de criptografia, e exige pagamento de resgate (ransom) para restabelecer o acesso. A principal medida de proteção é manter backups atualizados e desconectados, além de manter sistemas e antivírus atualizados.",
    legalBasis: "Conceito-chave: códigos maliciosos (Cartilha de Segurança para Internet – CERT.br)",
    lawText:
      "Ransomware é um tipo de código malicioso que torna inacessíveis os dados armazenados em um equipamento, geralmente usando criptografia, e que exige pagamento de resgate (ransom) para restabelecer o acesso ao usuário.",
    analysis: [
      "Errada. Spyware monitora as atividades do usuário e envia informações a terceiros.",
      "Errada. Worm se propaga automaticamente pelas redes, explorando vulnerabilidades, sem depender de hospedeiro.",
      "Correta. Criptografia dos dados + exigência de resgate = ransomware.",
      "Errada. Keylogger é um tipo de spyware que captura as teclas digitadas.",
      "Errada. Adware exibe propagandas ao usuário.",
    ],
    tip: "Palavras-chave da FCC: \"resgate\", \"criptografou os arquivos\" e \"pagamento em criptomoeda\" apontam para ransomware.",
    difficulty: "Fácil",
  }),
  mk({
    id: "inf-email-01",
    subject: "informatica",
    topic: "Internet, navegadores e correio eletrônico",
    statement: "Em relação aos protocolos de correio eletrônico, é correto afirmar que o",
    options: [
      "SMTP é utilizado para o envio de mensagens, enquanto o IMAP permite acessar e manipular as mensagens mantidas no servidor, sincronizando-as entre diferentes dispositivos.",
      "POP3 é utilizado exclusivamente para o envio de mensagens entre servidores.",
      "IMAP é utilizado para o envio de mensagens, e o SMTP, para o recebimento.",
      "HTTP é o protocolo padrão de envio de mensagens pelos clientes de e-mail, como o Microsoft Outlook.",
      "FTP é o protocolo utilizado para a sincronização das pastas de e-mail entre dispositivos.",
    ],
    correct: "A",
    summary:
      "O SMTP é o protocolo de envio de mensagens. Para o recebimento, há o POP3, que baixa as mensagens para o dispositivo (em regra, retirando-as do servidor), e o IMAP, que mantém as mensagens no servidor e sincroniza pastas e estados entre vários dispositivos.",
    legalBasis: "Conceito-chave: protocolos de correio eletrônico",
    lawText:
      "SMTP (portas 25/587): envio. POP3 (portas 110/995): recebimento com download das mensagens. IMAP (portas 143/993): acesso às mensagens no servidor, com sincronização.",
    analysis: [
      "Correta. SMTP envia; IMAP acessa e sincroniza as mensagens no servidor.",
      "Errada. POP3 é protocolo de recebimento.",
      "Errada. As funções estão invertidas.",
      "Errada. O HTTP é usado no webmail (navegador), mas o envio pelos clientes de e-mail utiliza SMTP.",
      "Errada. FTP é protocolo de transferência de arquivos.",
    ],
    tip: "Mnemônico popular: SMTP = \"Sua Mensagem Tá Partindo\".",
  }),
  mk({
    id: "inf-windows-01",
    subject: "informatica",
    topic: "Windows 10/11: conceitos e atalhos",
    statement:
      "No Windows 10, em português, a combinação de teclas que bloqueia o computador, exigindo nova autenticação do usuário para retomar a sessão, é",
    options: ["Windows + D", "Windows + L", "Windows + E", "Ctrl + Alt + Tab", "Alt + F4"],
    correct: "B",
    summary:
      "O atalho Windows + L bloqueia a sessão (L de \"lock\"), mantendo os programas abertos e exigindo nova autenticação. É uma boa prática de segurança ao se afastar da estação de trabalho.",
    legalBasis: "Conceito-chave: atalhos de teclado do Windows",
    lawText:
      "Windows + L: bloqueia o computador; Windows + D: exibe/oculta a área de trabalho; Windows + E: abre o Explorador de Arquivos; Alt + F4: fecha o aplicativo ativo; Ctrl + Alt + Tab: exibe os aplicativos abertos para alternância.",
    analysis: [
      "Errada. Windows + D exibe ou oculta a área de trabalho.",
      "Correta. Windows + L bloqueia o computador.",
      "Errada. Windows + E abre o Explorador de Arquivos.",
      "Errada. Ctrl + Alt + Tab exibe os aplicativos abertos, permitindo alternar entre eles.",
      "Errada. Alt + F4 fecha a janela ou o aplicativo ativo.",
    ],
    tip: "L de \"Lock\" (bloquear) e E de \"Explorer\" (Explorador de Arquivos).",
    difficulty: "Fácil",
  }),
  mk({
    id: "inf-backup-01",
    subject: "informatica",
    topic: "Segurança da informação: malwares, golpes e backup",
    statement:
      "Uma política de backup prevê um backup completo aos domingos e, nos demais dias, cópias apenas dos arquivos criados ou modificados desde o último backup realizado, seja ele completo ou não. O tipo de backup realizado nos demais dias é denominado",
    options: ["diferencial.", "incremental.", "espelhado.", "normal.", "de cópia."],
    correct: "B",
    summary:
      "O backup incremental copia somente os arquivos criados ou alterados desde o último backup de qualquer tipo (completo ou incremental) e os marca como copiados. É rápido para ser feito, mas a restauração exige o último completo e todos os incrementais posteriores. O diferencial copia o que mudou desde o último backup completo.",
    legalBasis: "Conceito-chave: tipos de backup",
    lawText:
      "Completo (normal): copia todos os arquivos selecionados. Incremental: copia o que mudou desde o último backup (completo ou incremental). Diferencial: copia o que mudou desde o último backup completo.",
    analysis: [
      "Errada. O diferencial toma como referência sempre o último backup completo.",
      "Correta. \"Desde o último backup, seja ele completo ou não\" define o incremental.",
      "Errada. O espelhamento replica os dados continuamente, sem manter versões anteriores.",
      "Errada. O backup normal é o completo.",
      "Errada. O backup de cópia copia todos os arquivos selecionados sem marcá-los, não interferindo na rotina.",
    ],
    tip: "Restauração: completo + TODOS os incrementais; ou completo + apenas o ÚLTIMO diferencial.",
  }),

  /* ========================= RACIOCÍNIO LÓGICO-MATEMÁTICO ========================= */
  mk({
    id: "rl-negacao-01",
    subject: "raciocinio",
    topic: "Proposições, conectivos, equivalências e negações",
    statement: "A negação lógica da afirmação “Todos os servidores do setor são pontuais” é:",
    options: [
      "Nenhum servidor do setor é pontual.",
      "Algum servidor do setor não é pontual.",
      "Todos os servidores do setor não são pontuais.",
      "Algum servidor do setor é pontual.",
      "Nenhum servidor do setor deixa de ser pontual.",
    ],
    correct: "B",
    summary:
      "Para negar uma proposição universal afirmativa (“Todo A é B”), basta mostrar que existe pelo menos um A que não é B: “Algum A não é B”. A afirmação “Nenhum servidor é pontual” é a contrária, e não a negação, pois ambas podem ser falsas ao mesmo tempo.",
    legalBasis: "Conceito-chave: negação de proposições categóricas",
    lawText:
      "~(Todo A é B) ≡ Algum A não é B. ~(Nenhum A é B) ≡ Algum A é B. ~(Algum A é B) ≡ Nenhum A é B.",
    analysis: [
      "Errada. “Nenhum” é a proposição contrária; não é a negação lógica.",
      "Correta. Negação de “Todo A é B”: “Algum A não é B”.",
      "Errada. Equivale a “Nenhum servidor é pontual”.",
      "Errada. É compatível com a afirmação original, logo não a nega.",
      "Errada. Equivale à própria afirmação original.",
    ],
    tip: "Para negar “Todo”, use “Pelo menos um/Algum/Existe” + NÃO.",
    difficulty: "Fácil",
  }),
  mk({
    id: "rl-equivalencia-01",
    subject: "raciocinio",
    topic: "Proposições, conectivos, equivalências e negações",
    statement: "Uma afirmação logicamente equivalente a “Se Ana é aprovada no concurso, então ela viaja de férias” é:",
    options: [
      "Se Ana não é aprovada no concurso, então ela não viaja de férias.",
      "Se Ana viaja de férias, então ela é aprovada no concurso.",
      "Se Ana não viaja de férias, então ela não é aprovada no concurso.",
      "Ana é aprovada no concurso e não viaja de férias.",
      "Ana é aprovada no concurso ou viaja de férias.",
    ],
    correct: "C",
    summary:
      "A condicional p → q tem duas equivalências clássicas: a contrapositiva (~q → ~p), obtida invertendo e negando as proposições, e a disjunção ~p ∨ q. Assim, “Se Ana não viaja de férias, então ela não é aprovada no concurso” é equivalente à frase original.",
    legalBasis: "Conceito-chave: equivalências da condicional",
    lawText: "p → q ≡ ~q → ~p (contrapositiva) ≡ ~p ∨ q. Negação: ~(p → q) ≡ p ∧ ~q.",
    analysis: [
      "Errada. É a inversa (~p → ~q), que não é equivalente.",
      "Errada. É a recíproca (q → p), que não é equivalente.",
      "Correta. É a contrapositiva (~q → ~p).",
      "Errada. É a negação da condicional (p ∧ ~q).",
      "Errada. p ∨ q não é equivalente; o correto seria “Ana não é aprovada ou viaja de férias”.",
    ],
    tip: "Contrapositiva: “inverte e nega”. Equivalência com “ou”: “nega a primeira OU mantém a segunda”. Negação: “mantém a primeira E nega a segunda”.",
  }),
  mk({
    id: "rl-sequencia-01",
    subject: "raciocinio",
    topic: "Sequências lógicas (números, letras e figuras)",
    statement: "Considere a sequência numérica: 3, 7, 15, 31, 63, ...\nMantido o padrão, o próximo termo da sequência é",
    options: ["95", "111", "127", "125", "131"],
    correct: "C",
    summary:
      "Cada termo é obtido multiplicando-se o anterior por 2 e somando-se 1: 3×2+1 = 7; 7×2+1 = 15; 15×2+1 = 31; 31×2+1 = 63; 63×2+1 = 127. Pelas diferenças, chega-se ao mesmo resultado: 4, 8, 16, 32 e, a seguir, 64 (63 + 64 = 127).",
    legalBasis: "Conceito-chave: lei de formação de sequências",
    lawText: "aₙ = 2·aₙ₋₁ + 1, ou diferenças sucessivas que dobram: 4, 8, 16, 32, 64...",
    analysis: [
      "Errada. 95 = 63 + 32 repete a última diferença, em vez de dobrá-la.",
      "Errada. Não obedece ao padrão da sequência.",
      "Correta. 63 × 2 + 1 = 127.",
      "Errada. 125 = 63 × 2 − 1, o que inverte a operação do padrão.",
      "Errada. Não obedece ao padrão da sequência.",
    ],
    tip: "Primeiro teste as diferenças entre termos consecutivos; se elas crescerem de forma geométrica, procure um padrão multiplicativo.",
    difficulty: "Fácil",
  }),
  mk({
    id: "rl-porcentagem-01",
    subject: "raciocinio",
    topic: "Problemas aritméticos: frações, porcentagem, razão e proporção",
    statement:
      "O preço de um produto sofreu um aumento de 20% e, em seguida, um desconto de 20% sobre o novo valor. Em relação ao preço inicial, o preço final é",
    options: ["igual ao preço inicial.", "4% menor.", "4% maior.", "2% menor.", "20% menor."],
    correct: "B",
    summary:
      "Variações percentuais sucessivas se multiplicam, pois incidem sobre bases diferentes: 1,20 × 0,80 = 0,96. O preço final corresponde a 96% do inicial, ou seja, é 4% menor. Com um valor inicial de R$ 100,00: 100 → 120 → 96.",
    legalBasis: "Conceito-chave: variações percentuais sucessivas",
    lawText: "Fator final = (1 + i₁) × (1 − i₂) = 1,20 × 0,80 = 0,96 → redução de 4%.",
    analysis: [
      "Errada. Os percentuais não se compensam, porque incidem sobre bases diferentes.",
      "Correta. 0,96 do valor inicial = 4% a menos.",
      "Errada. O resultado é uma redução, não um aumento.",
      "Errada. A redução é de 4%.",
      "Errada. A redução é de 4%.",
    ],
    tip: "Use sempre 100 como valor inicial em questões de porcentagem: o resultado sai direto em %.",
    difficulty: "Fácil",
  }),
  mk({
    id: "rl-regra3-01",
    subject: "raciocinio",
    topic: "Regra de três simples e composta",
    statement:
      "Em uma repartição, 6 servidores, trabalhando no mesmo ritmo, analisam 240 processos em 5 dias. Mantidas as mesmas condições, 9 servidores analisarão 432 processos em",
    options: ["4 dias.", "5 dias.", "6 dias.", "7 dias.", "8 dias."],
    correct: "C",
    summary:
      "A produtividade individual é de 240 ÷ (6 × 5) = 8 processos por servidor por dia. Com 9 servidores, analisam-se 9 × 8 = 72 processos por dia. Logo, 432 ÷ 72 = 6 dias. Pela regra de três composta: dias = 5 × (432/240) × (6/9) = 6.",
    legalBasis: "Conceito-chave: regra de três composta",
    lawText:
      "Mais servidores → menos dias (grandezas inversamente proporcionais); mais processos → mais dias (grandezas diretamente proporcionais).",
    analysis: [
      "Errada. Em 4 dias, 9 servidores analisariam 9 × 8 × 4 = 288 processos.",
      "Errada. Em 5 dias, seriam analisados 360 processos.",
      "Correta. 9 × 8 × 6 = 432 processos.",
      "Errada. Em 7 dias, seriam analisados 504 processos.",
      "Errada. Em 8 dias, seriam analisados 576 processos.",
    ],
    tip: "Calcular a produtividade unitária (por pessoa/dia) evita erros de proporcionalidade inversa.",
  }),
];
