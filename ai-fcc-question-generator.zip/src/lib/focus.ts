import type { BankQuestion } from "./types";
import { escapeRe, normalize, stem, tokens } from "./text";
import { levelFor, matchSubject, type RefTopic, type SubjectDef } from "./subjects";

export interface LegalReferenceNote {
  legalBasis: string;
  lawText: string;
}

export interface FocusedThemeDef {
  key: string;
  label: string;
  parentSubjectKey: string;
  /** Termos que ativam este tema específico (avaliados com prioridade sobre a matéria geral). */
  matchTerms: string[];
  /** Subtópicos 100% internos a este tema (nunca saem do tema). */
  subtopics: RefTopic[];
  /** Dispositivos legais / regras oficiais para ancorar a IA com precisão máxima neste tema. */
  references: LegalReferenceNote[];
}

const t = (name: string, relevance: number, why: string): RefTopic => ({ name, relevance, why });

/**
 * Catálogo de temas específicos campeões da FCC.
 * Quando o usuário digita qualquer um destes temas, 100% da pesquisa e 100% das questões
 * ficam travadas estritamente dentro do tema (sem misturar outros tópicos da matéria).
 */
export const FOCUSED_THEMES: FocusedThemeDef[] = [
  {
    key: "crase",
    label: "Crase (Emprego do Acento Grave)",
    parentSubjectKey: "portugues",
    matchTerms: ["crase", "acento grave"],
    subtopics: [
      t("Crase: regra geral (preposição 'a' + artigo feminino 'a/as')", 98, "Substituição por termo masculino correspondente (a → ao)."),
      t("Crase proibida: antes de verbos, palavras masculinas e artigo indefinido", 95, "A FCC cobra frases com 'começou à', 'a prazo', 'à uma'."),
      t("Crase proibida: antes de pronomes e após outra preposição", 92, "Pronomes pessoais/indefinidos e preposições (para, desde, após, entre)."),
      t("Crase proibida: 'a' no singular diante de palavra no plural", 90, "Clássico da FCC: 'refere-se a situações' (sem crase) x 'às situações'."),
      t("Crase obrigatória: locuções adverbiais, prepositivas e conjuntivas femininas e horas", 88, "Às vezes, à medida que, à procura de, às 14 horas."),
      t("Crase facultativa: pronomes possessivos femininos, nomes próprios femininos e 'até a'", 82, "Casos em que a presença ou ausência do acento mantém a correção."),
      t("Crase com pronomes demonstrativos (aquele/aquela/aquilo) e relativos (a qual/as quais)", 80, "Fusão da preposição 'a' com o 'a' inicial de aquele/aquela/aquilo."),
    ],
    references: [
      {
        legalBasis: "Norma-padrão: emprego do acento indicativo de crase",
        lawText:
          "1) Regra geral: ocorre crase na fusão da preposição 'a' com o artigo feminino 'a(s)' ou com o 'a' inicial de aquele(s), aquela(s), aquilo e a qual/as quais.\n2) Crase PROIBIDA: antes de palavra masculina, antes de verbo, antes de artigo indefinido (uma), antes de pronomes que repelem artigo (ela, esta, essa, toda, cada, qualquer, ninguém, alguém), após outra preposição (para, perante, após, desde, com, entre), entre palavras repetidas (cara a cara, dia a dia) e quando o 'a' está no singular diante de palavra no plural.\n3) Crase FACULTATIVA: antes de pronome possessivo feminino singular (minha, sua, nossa), antes de nome próprio feminino e após a preposição 'até'.\n4) Crase OBRIGATÓRIA: em locuções adverbiais, prepositivas e conjuntivas femininas (às pressas, à medida que, à espera de) e na indicação exata de horas (às 10h).",
      },
    ],
  },
  {
    key: "concordancia",
    label: "Concordância Verbal e Nominal",
    parentSubjectKey: "portugues",
    matchTerms: ["concordancia", "verbos impessoais", "sujeito posposto"],
    subtopics: [
      t("Concordância verbal com sujeito posposto e longo", 96, "Verbos existir, faltar, restar, caber e bastar concordam com o núcleo posposto."),
      t("Verbos impessoais: haver (existir/ocorrer) e fazer (tempo decorrido)", 95, "Ficam na 3ª pessoa do singular e transmitem a impessoalidade ao auxiliar."),
      t("Concordância com voz passiva sintética (partícula apassivadora 'se')", 90, "Alugam-se salas / Vendem-se casas vs. índice de indeterminação (Precisa-se de técnicos)."),
      t("Concordância com expressões partitivas, porcentagens e coletivos", 84, "A maioria dos servidores aprovou/aprovaram; 1% / 25% do quadro."),
      t("Concordância nominal: anexo, incluso, mesmo, próprio, bastante, meio e caro", 82, "Anexo/incluso concordam; 'em anexo' é invariável; meio = um pouco (invariável)."),
      t("Concordância com 'é proibido', 'é necessário' e 'é bom'", 78, "Sem determinante = invariável (É proibido entrada); com artigo = variável (É proibida a entrada)."),
    ],
    references: [
      {
        legalBasis: "Norma-padrão: concordância verbal e nominal",
        lawText:
          "1) Verbos impessoais: 'haver' (no sentido de existir, ocorrer ou tempo decorrido) e 'fazer' (indicando tempo decorrido ou clima) não têm sujeito e permanecem na 3ª pessoa do singular, inclusive o verbo auxiliar (Deve haver soluções; Faz dez anos).\n2) Verbos pessoais ('existir', 'faltar', 'restar', 'ocorrer', 'acontecer', 'sobrar'): concordam normalmente com o sujeito, mesmo posposto (Devem existir soluções; Faltam dois dias).\n3) Partícula 'se': com verbo transitivo direto, o verbo concorda com o sujeito paciente (Analisaram-se os recursos); com verbo transitivo indireto ou intransitivo, o verbo fica na 3ª pessoa do singular (Trata-se de questões urgentes; Necessita-se de servidores).\n4) Concordância nominal: 'anexo', 'incluso', 'mesmo' (próprio), 'quite' e 'leso' concordam em gênero e número; 'em anexo' e 'meio' (advérbio = um pouco) são invariáveis.",
      },
    ],
  },
  {
    key: "regencia",
    label: "Regência Verbal e Nominal",
    parentSubjectKey: "portugues",
    matchTerms: ["regencia", "transitividade"],
    subtopics: [
      t("Regência de assistir, visar e aspirar (mudança de sentido)", 96, "Assistir (ver) = a; visar (almejar) = a; aspirar (almejar) = a."),
      t("Regência de preferir, obedecer, desobedecer e responder", 92, "Prefere-se X a Y (sem 'mais' e sem 'do que'); obedecer/desobedecer exigem 'a'."),
      t("Regência de implicar, acarretar, proceder e chegar/ir", 88, "Implicar (acarretar) é VTD (implica custos, sem 'em'); chegar/ir exigem 'a', não 'em'."),
      t("Regência de esquecer, lembrar, informar, avisar e pagar/perdoar", 84, "Esquecer/lembrar sem pronome = VTD; com pronome (esquecer-se/lembrar-se) = VTI (de)."),
      t("Regência com pronomes relativos (preposição antes de que/quem/qual/cujo)", 82, "O cargo a que aspiro; a lei a cujos artigos obedecemos."),
    ],
    references: [
      {
        legalBasis: "Norma-padrão: regência verbal e nominal",
        lawText:
          "1) Assistir (ver/presenciar) = VTI (a); (dar assistência) = VTD/VTI.\n2) Visar (mirar/pôr visto) = VTD; (ter em vista/almejar) = VTI (a).\n3) Aspirar (sorver/inalar) = VTD; (almejar) = VTI (a).\n4) Preferir = VTDI (preferir uma coisa A outra), sem 'mais', 'muito mais' ou 'do que'.\n5) Obedecer e desobedecer = VTI (a).\n6) Implicar (no sentido de acarretar) = VTD, sem preposição 'em'.\n7) Pagar e perdoar = VTD para coisa (pagar a conta) e VTI (a) para pessoa (pagar ao fornecedor).\n8) Informar, avisar, cientificar, notificar = VTDI (informar algo a alguém OU informar alguém de/sobre algo).",
      },
    ],
  },
  {
    key: "pontuacao",
    label: "Pontuação (Emprego da Vírgula, Ponto e Vírgula, Dois-Pontos e Travessão)",
    parentSubjectKey: "portugues",
    matchTerms: ["pontuacao", "virgula", "travessao"],
    subtopics: [
      t("Proibição de vírgula entre sujeito e verbo e entre verbo e complementos", 96, "Erro clássico cobrado pela FCC em períodos longos."),
      t("Vírgula em orações subordinadas adverbiais antepostas ou intercaladas", 92, "Quando antepostas à principal, exigem vírgula."),
      t("Orações adjetivas explicativas (com vírgula) x restritivas (sem vírgula)", 90, "Mudança de sentido e isolamento obrigatório por dupla vírgula quando intercaladas."),
      t("Isolamento de aposto, vocativo e adjuntos adverbiais deslocados", 86, "Termos intercalados devem ficar entre duas vírgulas (ou dois travessões)."),
      t("Emprego de dois-pontos, ponto e vírgula e travessões", 78, "Substituição de vírgulas por travessões ou parênteses em termos explicativos."),
    ],
    references: [
      {
        legalBasis: "Norma-padrão: pontuação",
        lawText:
          "1) É PROIBIDO usar vírgula entre sujeito e predicado, entre verbo e seus complementos (OD/OI) e entre nome e complemento nominal ou adjunto adnominal.\n2) Usa-se vírgula para isolar: aposto explicativo, vocativo, adjunto adverbial deslocado de longa extensão, oração subordinada adverbial anteposta ou intercalada e oração subordinada adjetiva explicativa.\n3) Termo intercalado no meio da oração exige DUAS vírgulas (uma antes e outra depois), que podem ser substituídas por dois travessões ou parênteses.",
      },
    ],
  },
  {
    key: "pronomes",
    label: "Pronomes: Emprego e Colocação Pronominal (Próclise, Mesóclise e Ênclise)",
    parentSubjectKey: "portugues",
    matchTerms: ["pronome", "colocacao pronominal", "proclise", "enclise", "mesoclise"],
    subtopics: [
      t("Próclise obrigatória com palavras atrativas (negações, advérbios, relativos, indefinidos e conjunções)", 96, "Não, nunca, que, quem, onde, tudo, ninguém, quando, embora."),
      t("Proibição de iniciar período ou usar pronome após pausa com oblíquo átono", 92, "Usa-se ênclise no início de frase e após vírgula."),
      t("Emprego de o/a/os/as (OD) x lhe/lhes (OI) e adaptações fonéticas (lo, la, no, na)", 88, "'Lhe' substitui apenas objeto indireto (a ele/a ela)."),
      t("Pronomes relativos: que, quem, onde/aonde e cujo", 85, "'Cujo' indica posse, concorda com o consequente e não admite artigo depois."),
      t("Colocação pronominal em locuções verbais e mesóclise com futuro", 78, "Futuro do presente e do pretérito sem fator de próclise exigem mesóclise."),
    ],
    references: [
      {
        legalBasis: "Norma-padrão: emprego e colocação dos pronomes",
        lawText:
          "1) Próclise obrigatória diante de palavras atrativas: palavras negativas (não, nunca, jamais, nada, ninguém), advérbios sem vírgula, pronomes relativos (que, quem, qual, onde, cujo), pronomes indefinidos (tudo, todos, alguém, cada) e conjunções subordinativas (quando, se, embora, porque, conforme).\n2) É vedado iniciar período com pronome oblíquo átono ou colocá-lo após vírgula.\n3) O, a, os, as (e variantes lo, la, no, na) exercem função de objeto direto; lhe, lhes exercem função de objeto indireto.\n4) 'Cujo(a)(s)' estabelece relação de posse entre antecedente e consequente e nunca é seguido de artigo.",
      },
    ],
  },
  {
    key: "atos-administrativos",
    label: "Atos Administrativos",
    parentSubjectKey: "administrativo",
    matchTerms: ["ato administrativo", "atos administrativos", "anulacao e revogacao", "atributos do ato", "elementos do ato", "convalidacao"],
    subtopics: [
      t("Atos administrativos: elementos/requisitos (competência, finalidade, forma, motivo e objeto)", 96, "Competência, finalidade e forma são vinculados; motivo e objeto compõem o mérito nos discricionários."),
      t("Atributos dos atos administrativos (PATI: presunção de legitimidade, autoexecutoriedade, tipicidade e imperatividade)", 94, "Nem todos os atributos estão em todos os atos (ex.: autoexecutoriedade e imperatividade)."),
      t("Extinção dos atos: anulação (ilegalidade, ex tunc) x revogação (mérito, ex nunc)", 98, "Tema nº 1 da FCC em Atos Administrativos (Súmula 473 do STF e art. 53 da Lei 9.784/99)."),
      t("Convalidação (art. 55 da Lei 9.784/99) e decadência quinquenal (art. 54)", 90, "Vícios sanáveis de competência (não exclusiva) e forma (não essencial); prazo de 5 anos."),
      t("Espécies de atos (normativos, ordinatórios, negociais, enunciativos e punitivos) e atos que não admitem revogação", 84, "Atos vinculados, consumados, enunciativos e que geram direito adquirido são irrevogáveis."),
      t("Cassação, caducidade, contraposição e teoria dos motivos determinantes", 80, "A validade do ato vincula-se à veracidade dos motivos alegados."),
    ],
    references: [
      {
        legalBasis: "Lei nº 9.784/1999, arts. 53, 54 e 55; Súmula 473 do STF",
        lawText:
          "Art. 53. A Administração deve anular seus próprios atos, quando eivados de vício de legalidade, e pode revogá-los por motivo de conveniência ou oportunidade, respeitados os direitos adquiridos.\nArt. 54. O direito da Administração de anular os atos administrativos de que decorram efeitos favoráveis para os destinatários decai em cinco anos, contados da data em que foram praticados, salvo comprovada má-fé.\nArt. 55. Em decisão na qual se evidencie não acarretarem lesão ao interesse público nem prejuízo a terceiros, os atos que apresentarem defeitos sanáveis poderão ser convalidados pela própria Administração.\nSúmula 473 do STF: A administração pode anular seus próprios atos, quando eivados de vícios que os tornam ilegais, porque deles não se originam direitos; ou revogá-los, por motivo de conveniência ou oportunidade, respeitados os direitos adquiridos, e ressalvada, em todos os casos, a apreciação judicial.",
      },
    ],
  },
  {
    key: "poderes-administrativos",
    label: "Poderes Administrativos",
    parentSubjectKey: "administrativo",
    matchTerms: ["poderes administrativos", "poder de policia", "poder hierarquico", "poder disciplinar", "poder regulamentar", "abuso de poder"],
    subtopics: [
      t("Poder de polícia: conceito (art. 78 do CTN), atributos (DAC) e ciclos de polícia", 96, "Discricionariedade, autoexecutoriedade e coercibilidade; vínculo geral com particulares."),
      t("Poder disciplinar x poder de polícia e poder hierárquico", 94, "Vínculo especial (servidores e contratados) x vínculo geral."),
      t("Poder hierárquico: ordenar, coordenar, controlar, delegar e avocar", 90, "Inexiste hierarquia entre a Administração Direta e as entidades da Administração Indireta."),
      t("Poder regulamentar / normativo (art. 84, IV e VI, da CF/88)", 85, "Decretos regulamentares (fiel execução da lei) e decretos autônomos."),
      t("Abuso de poder: excesso de poder (vício de competência) x desvio de poder/finalidade", 88, "A FCC cobra casos práticos de remoção punitiva como desvio de finalidade."),
    ],
    references: [
      {
        legalBasis: "Código Tributário Nacional (Lei nº 5.172/1966), art. 78; CF/1988, art. 84, IV e VI",
        lawText:
          "CTN, Art. 78. Considera-se poder de polícia atividade da administração pública que, limitando ou disciplinando direito, interêsse ou liberdade, regula a prática de ato ou abstenção de fato, em razão de interêsse público concernente à segurança, à higiene, à ordem, aos costumes, à disciplina da produção e do mercado, ao exercício de atividades econômicas dependentes de concessão ou autorização do Poder Público, à tranqüilidade pública ou ao respeito à propriedade e aos direitos individuais ou coletivos.\nParágrafo único. Considera-se regular o exercício do poder de polícia quando desempenhado pelo órgão competente nos limites da lei aplicável, com observância do processo legal e, tratando-se de atividade que a lei tenha como discricionária, sem abuso ou desvio de poder.",
      },
    ],
  },
  {
    key: "organizacao-administrativa",
    label: "Organização Administrativa (Administração Direta e Indireta)",
    parentSubjectKey: "administrativo",
    matchTerms: ["organizacao administrativa", "administracao indireta", "autarquia", "empresa publica", "sociedade de economia mista", "descentralizacao", "desconcentracao"],
    subtopics: [
      t("Descentralização x desconcentração administrativa e órgãos públicos", 96, "Desconcentração = mesma PJ (há hierarquia); descentralização = outra PJ (tutela/controle finalístico, sem hierarquia)."),
      t("Autarquias: criação por lei específica, regime de direito público e prerrogativas", 95, "Art. 37, XIX, da CF e art. 5º, I, do DL 200/67."),
      t("Empresas públicas e sociedades de economia mista: autorização legal, capital e foro", 92, "EP = 100% público, qualquer forma societária (JF se federal); SEM = capital misto, sempre S/A (Justiça Estadual)."),
      t("Fundações públicas e agências reguladoras / executivas", 84, "Lei complementar define áreas de atuação das fundações (art. 37, XIX, CF)."),
    ],
    references: [
      {
        legalBasis: "CF/1988, art. 37, XIX e XX; Decreto-Lei nº 200/1967, arts. 4º e 5º",
        lawText:
          "CF, art. 37, XIX - somente por lei específica poderá ser criada autarquia e autorizada a instituição de empresa pública, de sociedade de economia mista e de fundação, cabendo à lei complementar, neste último caso, definir as áreas de sua atuação;\nXX - depende de autorização legislativa, em cada caso, a criação de subsidiárias das entidades mencionadas no inciso anterior, assim como a participação de qualquer delas em empresa privada;\nDL 200/1967, art. 5º: I - Autarquia - o serviço autônomo, criado por lei, com personalidade jurídica, patrimônio e receita próprios, para executar atividades típicas da Administração Pública; II - Empresa Pública - entidade dotada de personalidade jurídica de direito privado, com patrimônio próprio e capital exclusivo da União, criada para a exploração de atividade econômica; III - Sociedade de Economia Mista - entidade dotada de personalidade jurídica de direito privado, criada para a exploração de atividade econômica, sob a forma de sociedade anônima, cujas ações com direito a voto pertençam em sua maioria à União ou a entidade da Administração Indireta.",
      },
    ],
  },
  {
    key: "licitacoes",
    label: "Licitações e Contratos Administrativos (Lei nº 14.133/2021)",
    parentSubjectKey: "administrativo",
    matchTerms: ["licitac", "14133", "preg", "concorrencia", "dispensa de licitacao", "inexigibilidade", "contratos administrativos"],
    subtopics: [
      t("Modalidades de licitação na Lei nº 14.133/2021 (pregão, concorrência, concurso, leilão e diálogo competitivo)", 96, "Extinção de tomada de preços e convite; vedação de criação de novas modalidades (art. 28)."),
      t("Contratação direta: inexigibilidade (art. 74) x dispensa de licitação (art. 75) e licitação dispensada", 95, "Rol exemplificativo na inexigibilidade (inviabilidade de competição) x rol taxativo na dispensa."),
      t("Critérios de julgamento (menor preço, maior desconto, melhor técnica, técnica e preço, maior lance, maior retorno econômico)", 88, "Art. 33 da Lei nº 14.133/2021."),
      t("Fases do processo licitatório (art. 17) e agentes de contratação / pregoeiro", 85, "Regra: julgamento antes da habilitação, admitida inversão motivada."),
      t("Contratos administrativos: cláusulas exorbitantes, duração, garantias e extinção", 82, "Alteração unilateral até 25% (e 50% para reforma de edifício/equipamento)."),
    ],
    references: [
      {
        legalBasis: "Lei nº 14.133/2021, arts. 17, 28, 33, 74 e 75",
        lawText:
          "Art. 28. São modalidades de licitação: I - pregão; II - concorrência; III - concurso; IV - leilão; V - diálogo competitivo.\n§ 2º É vedada a criação de outras modalidades de licitação ou, ainda, a combinação daquelas referidas no caput deste artigo.\nArt. 33. O julgamento das propostas será realizado de acordo com os seguintes critérios: I - menor preço; II - maior desconto; III - melhor técnica ou conteúdo artístico; IV - técnica e preço; V - maior lance, no caso de leilão; VI - maior retorno econômico.\nArt. 74. É inexigível a licitação quando inviável a competição, em especial nos casos de: I - aquisição de materiais, de equipamentos ou de gêneros ou contratação de serviços que só possam ser fornecidos por produtor, empresa ou representante comercial exclusivos; II - contratação de profissional do setor artístico, diretamente ou por meio de empresário exclusivo, desde que consagrado pela crítica especializada ou pela opinião pública; III - contratação dos seguintes serviços técnicos especializados de natureza predominantemente intelectual com profissionais ou empresas de notória especialização, vedada a inexigibilidade para serviços de publicidade e divulgação.",
      },
    ],
  },
  {
    key: "improbidade",
    label: "Improbidade Administrativa (Lei nº 8.429/1992 atualizada pela Lei nº 14.230/2021)",
    parentSubjectKey: "administrativo",
    matchTerms: ["improbidade", "8429", "14230", "enriquecimento ilicito", "lesao ao erario"],
    subtopics: [
      t("Elemento subjetivo: exigência de dolo específico em todas as modalidades (art. 1º, §§ 1º a 3º)", 98, "Extinção da modalidade culposa pela Lei nº 14.230/2021."),
      t("Atos de improbidade: enriquecimento ilícito (art. 9º), lesão ao erário (art. 10) e princípios (art. 11)", 95, "O art. 11 agora possui rol taxativo de condutas."),
      t("Sanções aplicáveis (art. 12): suspensão dos direitos políticos (até 14, 12 e 4 anos) e proibição de contratar", 92, "Novos prazos após a reforma de 2021."),
      t("Sujeitos ativos e particulares (arts. 2º e 3º) e nepotismo na LIA", 86, "Mera nomeação sem dolo de finalidade ilícita não configura improbidade."),
      t("Prescrição em 8 anos e prescrição intercorrente em 4 anos (art. 23)", 88, "Prazos e marcos interruptivos do art. 23."),
    ],
    references: [
      {
        legalBasis: "Lei nº 8.429/1992 (com a redação da Lei nº 14.230/2021), arts. 1º, 9º, 10, 11, 12 e 23",
        lawText:
          "Art. 1º, § 1º Consideram-se atos de improbidade administrativa as condutas dolosas tipificadas nos arts. 9º, 10 e 11 desta Lei, ressalvados tipos previstos em leis especiais.\n§ 2º Considera-se dolo a vontade livre e consciente de alcançar o resultado ilícito tipificado nos arts. 9º, 10 e 11 desta Lei, não bastando a voluntariedade do agente.\nArt. 12. Sanções: I - na hipótese do art. 9º (enriquecimento ilícito): perda dos bens/valores acrescidos ilicitamente, perda da função pública, suspensão dos direitos políticos até 14 anos, multa equivalente ao valor do acréscimo patrimonial e proibição de contratar por até 14 anos; II - na hipótese do art. 10 (lesão ao erário): ressarcimento do dano, perda da função pública, suspensão dos direitos políticos até 12 anos, multa equivalente ao valor do dano e proibição de contratar por até 12 anos; III - na hipótese do art. 11 (princípios): multa de até 24 vezes a remuneração e proibição de contratar por até 4 anos (sem perda da função e sem suspensão de direitos políticos).\nArt. 23. A ação para a aplicação das sanções previstas nesta Lei prescreve em 8 (oito) anos, contados a partir da ocorrência do fato ou, no caso de infrações permanentes, do dia em que cessou a permanência.",
      },
    ],
  },
  {
    key: "responsabilidade-civil-estado",
    label: "Responsabilidade Civil do Estado (Art. 37, § 6º, da CF/88)",
    parentSubjectKey: "administrativo",
    matchTerms: ["responsabilidade civil do estado", "responsabilidade extracontratual", "risco administrativo", "art 37 6"],
    subtopics: [
      t("Teoria do risco administrativo: responsabilidade objetiva (conduta, dano e nexo causal)", 98, "Art. 37, § 6º, da CF/88."),
      t("Pessoas jurídicas abrangidas: direito público e direito privado prestadoras de serviço público", 94, "Alcança usuários e terceiros não usuários do serviço (STF)."),
      t("Excludentes e atenuantes: culpa exclusiva da vítima, caso fortuito/força maior e culpa concorrente", 90, "Risco administrativo (admite excludentes) x risco integral."),
      t("Ação de regresso contra o agente público: responsabilidade subjetiva (dolo ou culpa)", 92, "O agente só responde regressivamente se agiu com dolo ou culpa."),
    ],
    references: [
      {
        legalBasis: "CF/1988, art. 37, § 6º",
        lawText:
          "§ 6º As pessoas jurídicas de direito público e as de direito privado prestadoras de serviços públicos responderão pelos danos que seus agentes, nessa qualidade, causarem a terceiros, assegurado o direito de regresso contra o responsável nos casos de dolo ou culpa.",
      },
    ],
  },
  {
    key: "art5-direitos-fundamentais",
    label: "Direitos e Garantias Fundamentais (Art. 5º da CF/88)",
    parentSubjectKey: "constitucional",
    matchTerms: ["art 5", "artigo 5", "direitos e garantias individuais", "direitos individuais", "direitos fundamentais"],
    subtopics: [
      t("Inviolabilidade do domicílio (art. 5º, XI), sigilo de correspondência e das comunicações (art. 5º, XII)", 98, "Ordem judicial só durante o dia; flagrante, desastre ou socorro a qualquer hora."),
      t("Liberdade de reunião (XVI), associação (XVII a XXI) e manifestação do pensamento (IV e V)", 94, "Reunião pacífica, sem armas, exige apenas prévio aviso (não autorização)."),
      t("Remédios constitucionais: HC, HD, MS, MI e Ação Popular (art. 5º, LXVIII a LXXIII)", 95, "Legitimidade, objeto e gratuidade de cada remédio."),
      t("Garantias penais e processuais: legalidade, irretroatividade, racismo, tortura e extradição (XL a LII)", 90, "Racismo e ação de grupos armados são inafiançáveis e imprescritíveis."),
      t("Direito de propriedade, desapropriação, requisição administrativa e pequena propriedade rural (XXII a XXVI)", 85, "Indenização ulterior na requisição administrativa, se houver dano."),
      t("Tratados internacionais de direitos humanos (art. 5º, § 3º)", 82, "3/5 dos votos, em 2 turnos, em cada Casa = equivalentes às emendas constitucionais."),
    ],
    references: [
      {
        legalBasis: "CF/1988, art. 5º, IV, XI, XII, XVI, XVII, XXV, XLII, XLIII, XLIV, LI, LXVIII a LXXIII e § 3º",
        lawText:
          "XI - a casa é asilo inviolável do indivíduo, ninguém nela podendo penetrar sem consentimento do morador, salvo em caso de flagrante delito ou desastre, ou para prestar socorro, ou, durante o dia, por determinação judicial;\nXVI - todos podem reunir-se pacificamente, sem armas, em locais abertos ao público, independentemente de autorização, desde que não frustrem outra reunião anteriormente convocada para o mesmo local, sendo apenas exigido prévio aviso à autoridade competente;\nXXV - no caso de iminente perigo público, a autoridade competente poderá usar de propriedade particular, assegurada ao proprietário indenização ulterior, se houver dano;\nXLII - a prática do racismo constitui crime inafiançável e imprescritível, sujeito à pena de reclusão, nos termos da lei;\nXLIV - constitui crime inafiançável e imprescritível a ação de grupos armados, civis ou militares, contra a ordem constitucional e o Estado Democrático;\nLI - nenhum brasileiro será extraditado, salvo o naturalizado, em caso de crime comum, praticado antes da naturalização, ou de comprovado envolvimento em tráfico ilícito de entorpecentes e drogas afins, na forma da lei;\n§ 3º Os tratados e convenções internacionais sobre direitos humanos que forem aprovados, em cada Casa do Congresso Nacional, em dois turnos, por três quintos dos votos dos respectivos membros, serão equivalentes às emendas constitucionais.",
      },
    ],
  },
  {
    key: "remedios-constitucionais",
    label: "Remédios Constitucionais (HC, HD, MS, MI e Ação Popular)",
    parentSubjectKey: "constitucional",
    matchTerms: ["remedios constitucionais", "habeas corpus", "habeas data", "mandado de seguranca", "mandado de injuncao", "acao popular"],
    subtopics: [
      t("Habeas Corpus (art. 5º, LXVIII) e Habeas Data (art. 5º, LXXII) — gratuidade (LXXVII)", 98, "HC = liberdade de locomoção; HD = informações pessoais do impetrante e retificação de dados."),
      t("Mandado de Segurança individual e coletivo (art. 5º, LXIX e LXX)", 95, "Direito líquido e certo não amparado por HC ou HD; legitimados do MS coletivo."),
      t("Mandado de Injunção (art. 5º, LXXI): falta de norma regulamentadora", 90, "Inviabilidade de exercício dos direitos e liberdades constitucionais e prerrogativas inerentes à nacionalidade, soberania e cidadania."),
      t("Ação Popular (art. 5º, LXXIII): legitimidade exclusiva do cidadão e isenção de custas", 92, "Salvo comprovada má-fé, o autor fica isento de custas judiciais e do ônus da sucumbência."),
    ],
    references: [
      {
        legalBasis: "CF/1988, art. 5º, LXVIII a LXXIII e LXXVII",
        lawText:
          "LXVIII - conceder-se-á habeas corpus sempre que alguém sofrer ou se achar ameaçado de sofrer violência ou coação em sua liberdade de locomoção, por ilegalidade ou abuso de poder;\nLXIX - conceder-se-á mandado de segurança para proteger direito líquido e certo, não amparado por habeas corpus ou habeas data, quando o responsável pela ilegalidade ou abuso de poder for autoridade pública ou agente de pessoa jurídica no exercício de atribuições do Poder Público;\nLXX - o mandado de segurança coletivo pode ser impetrado por: a) partido político com representação no Congresso Nacional; b) organização sindical, entidade de classe ou associação legalmente constituída e em funcionamento há pelo menos um ano, em defesa dos interesses de seus membros ou associados;\nLXXI - conceder-se-á mandado de injunção sempre que a falta de norma regulamentadora torne inviável o exercício dos direitos e liberdades constitucionais e das prerrogativas inerentes à nacionalidade, à soberania e à cidadania;\nLXXII - conceder-se-á habeas data: a) para assegurar o conhecimento de informações relativas à pessoa do impetrante, constantes de registros ou bancos de dados de entidades governamentais ou de caráter público; b) para a retificação de dados, quando não se prefira fazê-lo por processo sigiloso, judicial ou administrativo;\nLXXIII - qualquer cidadão é parte legítima para propor ação popular que vise a anular ato lesivo ao patrimônio público ou de entidade de que o Estado participe, à moralidade administrativa, ao meio ambiente e ao patrimônio histórico e cultural, ficando o autor, salvo comprovada má-fé, isento de custas judiciais e do ônus da sucumbência;\nLXXVII - são gratuitas as ações de habeas corpus e habeas data, e, na forma da lei, os atos necessários ao exercício da cidadania.",
      },
    ],
  },
  {
    key: "excel-planilhas",
    label: "Planilhas Eletrônicas (Microsoft Excel e LibreOffice Calc)",
    parentSubjectKey: "informatica",
    matchTerms: ["excel", "planilha", "calc", "procv", "somase", "referencia absoluta"],
    subtopics: [
      t("Referências relativas (A1), absolutas ($A$1) e mistas ($A1 / A$1) ao copiar fórmulas", 98, "Questão clássica da FCC com cópia/alça de preenchimento."),
      t("Funções matemáticas e estatísticas: SOMA, MÉDIA, MÁXIMO, MÍNIMO, MAIOR, MENOR e MULT", 94, "Diferença entre ':' (intervalo A1:A5) e ';' (argumentos separados A1;A5)."),
      t("Funções condicionais: SE, SOMASE, CONT.SE, CONT.VALORES e CONT.NÚM", 92, "Ordem dos argumentos e critérios entre aspas."),
      t("Funções de pesquisa e texto: PROCV, PROCX, ÍNDICE, CORRESP, ESQUERDA, DIREITA e CONCATENAR", 86, "4º argumento do PROCV (FALSO/0 = correspondência exata)."),
      t("Ordem de precedência dos operadores (%, ^, * e /, + e -, =) e mensagens de erro (#DIV/0!, #VALOR!, #NOME?, #REF!)", 82, "Potenciação (^) antes de multiplicação/divisão."),
    ],
    references: [
      {
        legalBasis: "Conceito-chave: fórmulas, funções e referências no Excel / Calc",
        lawText:
          "1) Referências: A1 (relativa: ajusta coluna e linha ao copiar), $A$1 (absoluta: fixa coluna e linha), $A1 (fixa coluna A), A$1 (fixa linha 1).\n2) Operadores de referência: dois-pontos ':' indica intervalo contínuo (A1:A4 = A1, A2, A3 e A4); ponto e vírgula ';' separa argumentos avulsos (A1;A4 = apenas A1 e A4).\n3) Precedência: parênteses (), porcentagem %, exponenciação ^, multiplicação * e divisão /, adição + e subtração -, concatenação &, comparação (=, <>, >, <).\n4) Funções: =SE(teste_lógico; valor_se_verdadeiro; valor_se_falso); =SOMASE(intervalo; critério; [intervalo_soma]); =PROCV(valor_procurado; matriz_tabela; núm_índice_coluna; [procurar_intervalo]); =MAIOR(matriz; k) retorna o k-ésimo maior valor.",
      },
    ],
  },
  {
    key: "seguranca-informacao",
    label: "Segurança da Informação, Malwares, Golpes e Backup",
    parentSubjectKey: "informatica",
    matchTerms: ["seguranca da informacao", "malware", "ransomware", "phishing", "backup", "criptografia", "virus", "worm", "trojan"],
    subtopics: [
      t("Códigos maliciosos (CERT.br): vírus, worm, trojan, ransomware, spyware (keylogger/screenlogger), rootkit e backdoor", 98, "Diferença entre vírus (exige hospedeiro/execução) e worm (propaga-se automaticamente pela rede)."),
      t("Golpes na internet: phishing, pharming (envenenamento de DNS), engenharia social e ransomware", 94, "Criptografia de arquivos + pedido de resgate = ransomware."),
      t("Rotinas de backup: completo (normal), incremental, diferencial e de cópia", 92, "Incremental (marca atributo e copia desde o último completo ou incremental) x Diferencial (desde o último completo)."),
      t("Princípios da segurança (CID/CIA): confidencialidade, integridade, disponibilidade, autenticidade e não repúdio", 86, "Assinatura digital garante autenticidade, integridade e não repúdio."),
      t("Firewall, antivírus, VPN, HTTPS/TLS e autenticação em dois fatores (MFA)", 80, "Diferença entre criptografia simétrica e assimétrica (chave pública e privada)."),
    ],
    references: [
      {
        legalBasis: "Conceito-chave: Cartilha de Segurança para Internet (CERT.br) e rotinas de backup",
        lawText:
          "1) Vírus: depende da execução de programa/arquivo hospedeiro para se propagar. Worm: programa autônomo que se propaga automaticamente pelas redes explorando vulnerabilidades. Cavalo de troia (Trojan): aparenta ser benigno, mas executa funções maliciosas sem se replicar. Ransomware: criptografa dados e exige pagamento de resgate. Spyware: monitora atividades (Keylogger captura teclas; Screenlogger captura tela). Rootkit: conjunto de programas para esconder e assegurar a presença de invasor. Backdoor: permite o retorno de um invasor.\n2) Backup: Normal/Completo copia tudo e limpa o marcador de arquivo; Incremental copia o que mudou desde o último backup normal ou incremental (e limpa o marcador); Diferencial copia o que mudou desde o último backup normal (e não limpa o marcador).",
      },
    ],
  },
  {
    key: "arquivologia-foco",
    label: "Arquivologia e Gestão de Documentos",
    parentSubjectKey: "arquivologia",
    matchTerms: ["arquivologia", "arquivistica", "tres idades", "ciclo vital", "gestao de documentos", "tabela de temporalidade", "8159"],
    subtopics: [
      t("Teoria das três idades (ciclo vital): arquivo corrente (1ª idade), intermediário (2ª idade) e permanente (3ª idade)", 98, "Art. 8º da Lei nº 8.159/1991: valor primário (corrente e intermediário) x valor secundário/histórico (permanente, inalienável e imprescritível)."),
      t("Operações de passagem entre idades: transferência (corrente → intermediário) x recolhimento (→ permanente)", 95, "Pegadinha clássica da FCC: trocar transferência por recolhimento."),
      t("Instrumentos de gestão: plano de classificação e tabela de temporalidade e destinação de documentos", 92, "A tabela de temporalidade define prazos de guarda nas fases corrente e intermediária e a destinação final (eliminação ou guarda permanente)."),
      t("Princípios arquivísticos: proveniência (respeito aos fundos), organicidade, unicidade, indivisibilidade e cumulatividade", 88, "O princípio da proveniência é a base da arquivística moderna."),
      t("Métodos de arquivamento (básicos: alfabético, geográfico, numérico simples/cronológico/dígito-terminal e ideográfico) e protocolo", 84, "Sistemas direto (consulta sem índice) x indireto (exige índice auxiliar, como nos métodos numéricos)."),
    ],
    references: [
      {
        legalBasis: "Lei nº 8.159/1991 (Política Nacional de Arquivos), arts. 3º, 8º, 9º e 10",
        lawText:
          "Art. 3º Considera-se gestão de documentos o conjunto de procedimentos e operações técnicas referentes à sua produção, tramitação, uso, avaliação e arquivamento em fase corrente e intermediária, visando a sua eliminação ou recolhimento para guarda permanente.\nArt. 8º Os documentos públicos são identificados como correntes, intermediários e permanentes.\n§ 1º Consideram-se documentos correntes aqueles em curso ou que, mesmo sem movimentação, constituam objeto de consultas freqüentes.\n§ 2º Consideram-se documentos intermediários aqueles que, não sendo de uso corrente nos órgãos produtores, por razões de interesse administrativo, aguardam a sua eliminação ou recolhimento para guarda permanente.\n§ 3º Consideram-se documentos permanentes os conjuntos de documentos de valor histórico, probatório e informativo que devem ser definitivamente preservados.\nArt. 10. Os documentos de valor permanente são inalienáveis e imprescritíveis.",
      },
    ],
  },
  {
    key: "crimes-administracao-publica",
    label: "Crimes contra a Administração Pública (Código Penal, arts. 312 a 337-A)",
    parentSubjectKey: "penal",
    matchTerms: ["crimes contra a administracao", "peculato", "concussao", "corrupcao passiva", "corrupcao ativa", "prevaricacao", "condescendencia criminosa"],
    subtopics: [
      t("Peculato: apropriação, desvio, furto e culposo (art. 312, §§ 2º e 3º, do CP)", 98, "No peculato culposo, a reparação do dano antes da sentença irrecorrível extingue a punibilidade; se posterior, reduz a pena pela metade."),
      t("Concussão (art. 316: exigir) x Corrupção passiva (art. 317: solicitar, receber ou aceitar promessa)", 96, "Diferença nos verbos nucleares: exigir (concussão) x solicitar/receber/aceitar (corrupção passiva) x oferecer/prometer (corrupção ativa, art. 333)."),
      t("Prevaricação (art. 319: interesse ou sentimento pessoal) x Corrupção passiva privilegiada (art. 317, § 2º: pedido ou influência de outrem)", 94, "Pegadinha clássica da FCC entre ceder a pedido de outrem e satisfazer interesse ou sentimento pessoal."),
      t("Condescendência criminosa (art. 320), advocacia administrativa (art. 321) e abandono de função (art. 323)", 86, "Indulgência do superior hierárquico ao deixar de responsabilizar subordinado."),
      t("Conceito penal de funcionário público e equiparação (art. 327 do CP)", 84, "Cargo, emprego ou função pública, ainda que transitoriamente ou sem remuneração."),
    ],
    references: [
      {
        legalBasis: "Código Penal (Decreto-Lei nº 2.848/1940), arts. 312, 316, 317, 319, 320 e 327",
        lawText:
          "Art. 312. Apropriar-se o funcionário público de dinheiro, valor ou qualquer outro bem móvel, público ou particular, de que tem a posse em razão do cargo, ou desviá-lo, em proveito próprio ou alheio: Pena - reclusão, de dois a doze anos, e multa.\n§ 2º Se o funcionário concorre culposamente para o crime de outrem: Pena - detenção, de três meses a um ano.\n§ 3º No caso do parágrafo anterior, a reparação do dano, se precede à sentença irrecorrível, extingue a punibilidade; se lhe é posterior, reduz de metade a pena imposta.\nArt. 316. Exigir, para si ou para outrem, direta ou indiretamente, ainda que fora da função ou antes de assumi-la, mas em razão dela, vantagem indevida: Pena - reclusão, de 2 (dois) a 12 (doze) anos, e multa.\nArt. 317. Solicitar ou receber, para si ou para outrem, direta ou indiretamente, ainda que fora da função ou antes de assumi-la, mas em razão dela, vantagem indevida, ou aceitar promessa de tal vantagem: Pena - reclusão, de 2 (dois) a 12 (doze) anos, e multa.\n§ 2º Se o funcionário pratica, deixa de praticar ou retarda ato de ofício, com infração de dever funcional, cedendo a pedido ou influência de outrem: Pena - detenção, de três meses a um ano, ou multa.\nArt. 319. Retardar ou deixar de praticar, indevidamente, ato de ofício, ou praticá-lo contra disposição expressa de lei, para satisfazer interesse ou sentimento pessoal: Pena - detenção, de três meses a um ano, e multa.\nArt. 320. Deixar o funcionário, por indulgência, de responsabilizar subordinado que cometeu infração no exercício do cargo ou, quando lhe falte competência, não levar o fato ao conhecimento da autoridade competente: Pena - detenção, de quinze dias a um mês, ou multa.",
      },
    ],
  },
];

export interface ResolvedFocus {
  /** Texto exato informado pelo usuário. */
  userInput: string;
  /** true quando o usuário pediu um tema/assunto específico em vez de uma disciplina inteira. */
  isSpecificTheme: boolean;
  /** Definição do tema específico (se reconhecido). */
  focusedTheme: FocusedThemeDef | null;
  /** Definição da disciplina-mãe (se reconhecida). */
  subjectDef: SubjectDef | null;
  /** Subtópicos de referência 100% focados no que o usuário pediu. */
  referenceTopics: Array<{ name: string; relevance: number; level: ReturnType<typeof levelFor>; why: string; sources: number[] }>;
  /** Notas oficiais (letra da lei / conceitos) do tema para ancorar a IA. */
  references: LegalReferenceNote[];
}

/**
 * Identifica com precisão se o usuário informou um TEMA ESPECÍFICO (ex.: "Crase", "Atos Administrativos",
 * "Licitações Lei 14.133", "Controle de Constitucionalidade") ou uma DISCIPLINA GERAL (ex.: "Direito Administrativo").
 * Garante que a lista de tópicos nunca expanda um tema específico para assuntos vizinhos.
 */
export function resolveFocus(input: string): ResolvedFocus {
  const userInput = input.trim();
  const n = normalize(userInput).replace(/[^a-z0-9/ ]/g, " ").replace(/\s+/g, " ").trim();

  // 1) Verifica primeiro o catálogo de temas específicos.
  for (const ft of FOCUSED_THEMES) {
    if (ft.matchTerms.some((term) => n.includes(term))) {
      const subjectDef = matchSubject(ft.parentSubjectKey) ?? matchSubject(userInput);
      return {
        userInput,
        isSpecificTheme: true,
        focusedTheme: ft,
        subjectDef,
        referenceTopics: ft.subtopics.map((st) => ({
          name: st.name,
          relevance: st.relevance,
          level: levelFor(st.relevance),
          why: st.why,
          sources: [],
        })),
        references: ft.references,
      };
    }
  }

  // 2) Verifica se o usuário digitou um dos subtópicos de uma matéria conhecida (ex.: "Remédios constitucionais", "Poder Judiciário", "Penalidades disciplinares").
  const subjectDef = matchSubject(userInput);
  if (subjectDef) {
    const inputToks = tokens(userInput).map(stem);
    const matchingRefs = subjectDef.reference.filter((ref) => {
      const refNorm = normalize(ref.name);
      return inputToks.some((st) => st.length >= 4 && !["direit", "public", "administr", "constituc", "portug", "inform", "racioc"].includes(st) && refNorm.includes(st));
    });

    // Se o usuário especificou um recorte dentro da matéria (ex.: "Direito Constitucional - Poder Judiciário" ou "Vacância e remoção na Lei 8.112"),
    // filtramos APENAS os recortes correspondentes + ângulos internos daquele recorte!
    if (matchingRefs.length > 0 && matchingRefs.length < subjectDef.reference.length) {
      const subtopics = buildInternalFacets(userInput, matchingRefs);
      return {
        userInput,
        isSpecificTheme: true,
        focusedTheme: null,
        subjectDef,
        referenceTopics: subtopics,
        references: [],
      };
    }

    // Caso contrário, o usuário digitou o nome da matéria geral (ex.: "Direito Administrativo", "Língua Portuguesa").
    return {
      userInput,
      isSpecificTheme: false,
      focusedTheme: null,
      subjectDef,
      referenceTopics: subjectDef.reference.map((st) => ({
        name: st.name,
        relevance: st.relevance,
        level: levelFor(st.relevance),
        why: st.why,
        sources: [],
      })),
      references: [],
    };
  }

  // 3) Tema livre/específico digitado pelo usuário (ex.: "Controle de Constitucionalidade", "Inquérito Policial", "LGPD", "Redação Oficial").
  return {
    userInput,
    isSpecificTheme: true,
    focusedTheme: null,
    subjectDef: null,
    referenceTopics: buildInternalFacets(userInput, []),
    references: [],
  };
}

/** Constrói recortes 100% internos para qualquer tema específico informado pelo usuário. */
function buildInternalFacets(theme: string, matched: RefTopic[]) {
  const base: RefTopic[] = [
    t(`${theme}: conceitos essenciais e literalidade da norma (Foco 100%)`, 98, `Cobrança direta dos conceitos e dispositivos centrais de ${theme} na FCC.`),
    ...matched,
    t(`${theme}: prazos, requisitos, competências e regras gerais`, 92, `A FCC explora prazos, condições e competências específicas de ${theme}.`),
    t(`${theme}: exceções legais, vedações e pegadinhas clássicas da FCC`, 88, `Troca de 'regra' por 'exceção' e termos restritivos ('apenas', 'sempre', 'vedado') em ${theme}.`),
    t(`${theme}: aplicação em situações práticas com personagens`, 84, `Casos hipotéticos de nível médio cobrando a aplicação direta de ${theme}.`),
    t(`${theme}: distinção entre conceitos próximos e julgamento de itens (I, II e III)`, 78, `Comparação entre institutos correlatos dentro de ${theme}.`),
  ];
  const seen = new Set<string>();
  return base
    .filter((x) => {
      const k = normalize(x.name);
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    })
    .slice(0, 6)
    .map((st) => ({
      name: st.name,
      relevance: st.relevance,
      level: levelFor(st.relevance),
      why: st.why,
      sources: [] as number[],
    }));
}

/**
 * Ângulos internos de elaboração estilo FCC para garantir que, quando o usuário pede N questões
 * sobre o MESMO tema específico, cada questão explore uma faceta diferente sem sair 1 milímetro do tema!
 */
export const FCC_INTERNAL_ANGLES = [
  "literalidade da norma / regra central e conceitos fundamentais",
  "exceções, vedações, prazos ou condições específicas (pegadinha clássica da FCC)",
  "situação prática hipotética com personagem aplicando o tema",
  "julgamento de afirmativas (itens I, II e III) sobre pontos distintos do tema",
  "distinção entre conceitos ou hipóteses próximas dentro do próprio tema",
  "preenchimento de lacunas ou conclusão lógica conforme a norma/regra do tema",
];

const GENERIC_PREFIX =
  /^(direit|nocoe|legisl|public|administr|constituc|portug|lingu|inform|racioc|logic|matem|concurs|nivel|medi|lei|art|decret|estatut|codig|foco|tema|assunt|conceit|regra|geral|gerai|essenc|aplicac|pratic|excec|servidor|feder|nacional|estad|municip)/;

function specificStems(text: string): string[] {
  return tokens(text)
    .filter((w) => !GENERIC_PREFIX.test(w))
    .map(stem)
    .filter((s) => s.length >= 3 && !GENERIC_PREFIX.test(s));
}

function matchFocusedThemeKey(text: string): string | null {
  const n = normalize(text).replace(/[^a-z0-9/ ]/g, " ").replace(/\s+/g, " ").trim();
  for (const ft of FOCUSED_THEMES) {
    if (ft.matchTerms.some((term) => n.includes(term))) return ft.key;
  }
  return null;
}

/**
 * Verifica se uma questão do banco curado corresponde ESTRITAMENTE ao tópico planejado (`itemTopic`)
 * e ao tema central do simulado (`quizSubject`).
 * Impede que uma questão de "Poderes Administrativos" ou "Férias (Lei 8.112)" entre num treino de
 * "Atos Administrativos", ou que "Concordância" entre num treino de "Crase".
 */
export function isStrictBankMatch(b: BankQuestion, itemTopic: string, quizSubject: string): boolean {
  const itemKey = matchFocusedThemeKey(itemTopic) ?? matchFocusedThemeKey(quizSubject);
  const bankKey = matchFocusedThemeKey(b.topic);

  // Se o item pedido pertence a um tema específico mapeado, exige a MESMA chave de tema no banco.
  if (itemKey) {
    return bankKey === itemKey;
  }
  // Se a questão do banco é de outro tema específico diferente do item pedido, rejeita se os tópicos não coincidirem.
  const bTopicNorm = normalize(b.topic);
  const itemNorm = normalize(itemTopic);
  if (bTopicNorm === itemNorm || itemNorm.includes(bTopicNorm) || bTopicNorm.includes(itemNorm)) {
    return true;
  }

  // Compara apenas os radicais realmente específicos do itemTopic com o título do tópico no banco.
  const itemSpec = specificStems(itemTopic);
  const subjSpec = specificStems(quizSubject);
  const targetStems = itemSpec.length ? itemSpec : subjSpec;
  if (!targetStems.length) return false;

  const matchedInTopic = targetStems.filter((st) => new RegExp(`\\b${escapeRe(st)}`).test(bTopicNorm)).length;
  const needTopic = Math.max(1, Math.ceil(targetStems.length * 0.6));
  return matchedInTopic >= needTopic;
}
