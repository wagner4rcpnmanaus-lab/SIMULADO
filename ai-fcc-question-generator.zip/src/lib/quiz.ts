import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { questions, quizzes } from "@/db/schema";
import { UUID_RE } from "./http";
import { shuffle } from "./text";
import {
  LETTERS,
  type Correction,
  type Letter,
  type PlanItem,
  type PublicQuiz,
  type QuestionOrigin,
  type QuizMode,
  type QuizStatus,
} from "./types";

export type QuizRow = typeof quizzes.$inferSelect;
export type QuestionRow = typeof questions.$inferSelect;

export function buildPlan(topics: string[], count: number): PlanItem[] {
  const letters = shuffle(Array.from({ length: count }, (_, i) => LETTERS[i % LETTERS.length])) as Letter[];
  return Array.from({ length: count }, (_, i) => ({
    position: i + 1,
    topic: topics[i % topics.length],
    letter: letters[i],
  }));
}

export function toCorrection(q: QuestionRow): Correction {
  return {
    correct: q.correct,
    isCorrect: q.userAnswer ? q.userAnswer === q.correct : null,
    summary: q.summary,
    legalBasis: q.legalBasis,
    lawText: q.lawText,
    lawUrl: q.lawUrl,
    analysis: q.analysis,
    tip: q.tip,
    difficulty: q.difficulty,
  };
}

export function toPublicQuiz(
  quiz: QuizRow,
  qs: QuestionRow[],
  cfg: { batchSize: number; concurrency: number },
): PublicQuiz {
  const finished = quiz.status === "finished";
  return {
    id: quiz.id,
    subject: quiz.subject,
    cargo: quiz.cargo,
    topics: quiz.topics,
    mode: quiz.mode as QuizMode,
    status: quiz.status as QuizStatus,
    questionCount: quiz.questionCount,
    answeredCount: quiz.answeredCount,
    correctCount: quiz.correctCount,
    engine: quiz.engine,
    createdAt: quiz.createdAt.toISOString(),
    finishedAt: quiz.finishedAt ? quiz.finishedAt.toISOString() : null,
    plan: quiz.plan.map((p) => ({ position: p.position, topic: p.topic })),
    batchSize: cfg.batchSize,
    concurrency: cfg.concurrency,
    questions: qs.map((q) => {
      const revealed = finished || (quiz.mode === "estudo" && q.userAnswer != null);
      return {
        id: q.id,
        position: q.position,
        topic: q.topic,
        supportText: q.supportText,
        statement: q.statement,
        options: q.options,
        origin: q.origin as QuestionOrigin,
        engine: q.engine,
        userAnswer: q.userAnswer ?? null,
        revealed,
        correction: revealed ? toCorrection(q) : undefined,
      };
    }),
  };
}

export async function loadQuiz(id: string): Promise<{ quiz: QuizRow; qs: QuestionRow[] } | null> {
  if (!UUID_RE.test(id)) return null;
  const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, id)).limit(1);
  if (!quiz) return null;
  const qs = await db.select().from(questions).where(eq(questions.quizId, id)).orderBy(asc(questions.position));
  return { quiz, qs };
}

/** Recalcula contadores e encerra o simulado quando todas as questões forem respondidas. */
export async function refreshCounters(quizId: string, forceFinish = false): Promise<QuizRow> {
  const data = await loadQuiz(quizId);
  if (!data) throw new Error("Simulado não encontrado");
  const { quiz, qs } = data;
  const answered = qs.filter((q) => q.userAnswer != null).length;
  const correct = qs.filter((q) => q.userAnswer != null && q.userAnswer === q.correct).length;
  const allAnswered = qs.length > 0 && answered >= quiz.questionCount;
  const finish = quiz.status !== "generating" && (forceFinish || allAnswered);
  const [updated] = await db
    .update(quizzes)
    .set({
      answeredCount: answered,
      correctCount: correct,
      status: finish ? "finished" : quiz.status,
      finishedAt: finish ? quiz.finishedAt ?? new Date() : quiz.finishedAt,
    })
    .where(eq(quizzes.id, quizId))
    .returning();
  return updated;
}
