import { and, desc, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure";
import { researches } from "@/db/schema";
import { chatJSON, getProvider } from "./ai";
import { resolveFocus } from "./focus";
import { RESEARCH_SYSTEM, researchPrompt } from "./prompts";
import { searchPortals } from "./search";
import { levelFor } from "./subjects";
import { clip, normalize, stemRegexes } from "./text";
import type { ResearchMethod, ResearchResult, ResearchTopic } from "./types";

type ResearchRow = typeof researches.$inferSelect;

interface AiResearch {
  topics?: Array<{ name?: unknown; relevance?: unknown; why?: unknown; sources?: unknown }>;
  summary?: unknown;
  styleTips?: unknown;
}

function defaultTipsFor(subject: string): string[] {
  return [
    `Em ${subject}, a FCC valoriza a literalidade da norma e os conceitos centrais: domine a redação exata dos dispositivos.`,
    `Atenção redobrada às trocas de prazos, números, hipóteses e palavras restritivas ("apenas", "sempre", "exclusivamente", "vedado") dentro de ${subject}.`,
    `A FCC costuma cobrar ${subject} por meio de casos hipotéticos com personagens e julgamento de itens (I, II e III).`,
    `Compare hipóteses parecidas dentro de ${subject} (regra geral x exceção), pois os distratores da banca invertem exatamente esses detalhes.`,
  ];
}

function toResult(row: ResearchRow): ResearchResult {
  return {
    id: row.id,
    subject: row.subject,
    cargo: row.cargo,
    topics: row.topics,
    sources: row.sources,
    summary: row.summary ?? "",
    styleTips: row.styleTips ?? [],
    searchLog: row.searchLog ?? [],
    method: row.method as ResearchMethod,
    engine: row.engine,
    createdAt: row.createdAt.toISOString(),
  };
}

function cleanTopics(raw: AiResearch["topics"], maxSource: number): ResearchTopic[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Set<string>();
  const out: ResearchTopic[] = [];
  for (const t of raw) {
    const name = typeof t?.name === "string" ? clip(t.name.trim(), 120) : "";
    if (!name || seen.has(normalize(name))) continue;
    seen.add(normalize(name));
    let rel = Number(t.relevance);
    if (!Number.isFinite(rel)) rel = 60;
    rel = Math.max(1, Math.min(100, Math.round(rel)));
    const sources = Array.isArray(t.sources)
      ? t.sources.map(Number).filter((n) => Number.isInteger(n) && n >= 1 && n <= maxSource)
      : [];
    out.push({
      name,
      relevance: rel,
      level: levelFor(rel),
      why: typeof t.why === "string" ? clip(t.why.trim(), 240) : "",
      sources: Array.from(new Set(sources)),
    });
  }
  return out.sort((a, b) => b.relevance - a.relevance).slice(0, 12);
}

function attachSourceIds(
  refTopics: ResearchTopic[],
  sources: ResearchResult["sources"],
  extracts: Record<number, string>,
): ResearchTopic[] {
  return refTopics.map((t) => {
    const res = stemRegexes(t.name);
    const need = Math.min(2, Math.max(1, res.length));
    const ids = sources
      .filter((s) => {
        const hay = normalize(`${s.title} ${s.snippet} ${extracts[s.id] ?? ""}`);
        return res.filter((re) => re.test(hay)).length >= need;
      })
      .map((s) => s.id)
      .slice(0, 4);
    return { ...t, sources: ids };
  });
}

export async function runResearch(subjectIn: string, cargoIn: string | null, force = false): Promise<ResearchResult> {
  await ensureSchema();
  const subject = subjectIn.trim();
  const cargo = cargoIn?.trim() || null;
  const key = `v2|${normalize(subject)}|${normalize(cargo ?? "")}`;

  if (!force) {
    const since = new Date(Date.now() - 24 * 3600 * 1000);
    const [hit] = await db
      .select()
      .from(researches)
      .where(and(eq(researches.subjectKey, key), gt(researches.createdAt, since)))
      .orderBy(desc(researches.createdAt))
      .limit(1);
    if (hit && hit.topics.length && hit.method !== "referencia") return { ...toResult(hit), cached: true };
  }

  const search = await searchPortals(subject, cargo);
  const provider = getProvider();
  const focus = resolveFocus(subject);
  const tipsFallback = defaultTipsFor(subject);
  let topics: ResearchTopic[] = [];
  let summary = "";
  let styleTips: string[] = [];
  let method: ResearchMethod;
  let engine: string;

  // Se não há IA premium e temos um mapeamento curado (de tema específico OU de disciplina),
  // usamos os recortes curados 100% focados no que o usuário pediu + fontes ao vivo dos portais.
  if (!provider.premium && (focus.focusedTheme || focus.subjectDef)) {
    topics = attachSourceIds(focus.referenceTopics, search.sources, search.extracts);
    const targetLabel = focus.focusedTheme?.label ?? focus.subjectDef?.label ?? subject;
    summary = focus.isSpecificTheme
      ? `Foco 100% em ${targetLabel}: desdobramento estrito dos pontos, regras e dispositivos mais cobrados pela FCC exclusivamente dentro deste tema${
          search.sources.length ? `, cruzado com ${search.sources.length} fonte(s) dos portais de concursos` : ""
        }.`
      : `Ranking de ${targetLabel} consolidado a partir dos padrões de cobrança da FCC em provas de nível médio${
          search.sources.length ? `, com ${search.sources.length} fonte(s) coletada(s) ao vivo nos portais de concursos` : ""
        }.`;
    styleTips = tipsFallback;
    method = search.sources.length ? "web" : "referencia";
    engine = focus.isSpecificTheme ? "Recorte 100% focado no tema + pesquisa ao vivo" : "Base curada + pesquisa ao vivo";
    search.log.push(`Foco 100%: ${targetLabel} (${topics.length} recortes estritos do tema)`);
    const [row] = await db
      .insert(researches)
      .values({ subject, subjectKey: key, cargo, topics, sources: search.sources, summary, styleTips, searchLog: search.log, method, engine })
      .returning();
    return toResult(row);
  }

  try {
    const { data, model } = await chatJSON<AiResearch>({
      system: RESEARCH_SYSTEM,
      user: researchPrompt(subject, cargo, search.sources, search.extracts, provider.premium ? 1800 : 900, focus.isSpecificTheme),
      temperature: 0.3,
      maxTokens: 3000,
      timeoutMs: provider.premium ? 90_000 : 120_000,
    });
    topics = cleanTopics(data.topics, search.sources.length);
    if (!topics.length) throw new Error("a IA não retornou assuntos");
    summary = typeof data.summary === "string" ? clip(data.summary.trim(), 600) : "";
    styleTips = Array.isArray(data.styleTips)
      ? data.styleTips.filter((x): x is string => typeof x === "string").map((s) => clip(s.trim(), 220)).slice(0, 6)
      : [];
    if (!styleTips.length) styleTips = tipsFallback;
    engine = `${provider.label} · ${model}`;
    method = search.sources.length ? "web+ia" : "ia";
    search.log.push(`Síntese por IA (Foco 100% em "${subject}"): ${engine}`);
  } catch (err) {
    search.log.push(`Síntese por IA indisponível: ${clip(String((err as Error)?.message ?? err), 90)}`);
    topics = attachSourceIds(focus.referenceTopics, search.sources, search.extracts);
    summary = `Desdobramento focado 100% em ${subject}, estruturado nos padrões de cobrança da FCC em provas de nível médio.`;
    styleTips = tipsFallback;
    method = search.sources.length ? "web" : "referencia";
    engine = "Recorte 100% focado no tema";
  }

  const [row] = await db
    .insert(researches)
    .values({ subject, subjectKey: key, cargo, topics, sources: search.sources, summary, styleTips, searchLog: search.log, method, engine })
    .returning();
  return toResult(row);
}
