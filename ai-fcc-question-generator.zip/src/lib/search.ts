import { hostOf, portalFor, TOP_PORTAL_DOMAINS } from "./portals";
import { clip, decodeEntities, escapeRe, normalize, sleep, stem, stripHtml, tokens } from "./text";
import type { ResearchSource } from "./types";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

interface RawResult {
  title: string;
  url: string;
  snippet: string;
  engine: string;
  content?: string;
}

async function fetchText(
  url: string,
  init: RequestInit = {},
  timeoutMs = 8000,
): Promise<{ status: number; text: string }> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      ...init,
      headers: {
        "User-Agent": UA,
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.5",
        ...((init.headers as Record<string, string> | undefined) ?? {}),
      },
      signal: ctrl.signal,
      cache: "no-store",
      redirect: "follow",
    });
    return { status: res.status, text: await res.text() };
  } finally {
    clearTimeout(timer);
  }
}

/* ----------------------------- Buscadores ----------------------------- */

async function duckduckgo(q: string): Promise<RawResult[]> {
  const { status, text } = await fetchText(
    `https://lite.duckduckgo.com/lite/?q=${encodeURIComponent(q)}&kl=br-pt`,
    {},
    7000,
  );
  if (status !== 200) throw new Error(`HTTP ${status}`);
  const out: RawResult[] = [];
  for (const part of text.split(/<a rel="nofollow" href="/).slice(1)) {
    if (!/class=['"]result-link['"]/.test(part.slice(0, 800))) continue;
    let href = decodeEntities(part.slice(0, part.indexOf('"')));
    const m = href.match(/[?&]uddg=([^&]+)/);
    if (m) href = decodeURIComponent(m[1]);
    if (href.startsWith("//")) href = `https:${href}`;
    if (!/^https?:\/\//.test(href) || /duckduckgo\.com\/y\.js/.test(href)) continue;
    const title = part.match(/class=['"]result-link['"][^>]*>([\s\S]*?)<\/a>/);
    const snip = part.match(/class=['"]result-snippet['"][^>]*>([\s\S]*?)<\/td>/);
    out.push({ title: stripHtml(title?.[1] ?? ""), url: href, snippet: stripHtml(snip?.[1] ?? ""), engine: "DuckDuckGo" });
  }
  return out;
}

async function bingRss(q: string): Promise<RawResult[]> {
  const { status, text } = await fetchText(
    `https://www.bing.com/search?format=rss&count=15&setlang=pt-BR&cc=BR&q=${encodeURIComponent(q)}`,
  );
  if (status !== 200) throw new Error(`HTTP ${status}`);
  const items = text.match(/<item>[\s\S]*?<\/item>/g) ?? [];
  return items
    .map((it) => {
      const g = (tag: string) => {
        const m = it.match(new RegExp(`<${tag}>([\\s\\S]*?)</${tag}>`));
        return m ? stripHtml(decodeEntities(m[1].replace(/<!\[CDATA\[|\]\]>/g, ""))) : "";
      };
      return { title: g("title"), url: g("link"), snippet: g("description"), engine: "Bing" };
    })
    .filter((r) => /^https?:\/\//.test(r.url) && !/bing\.com/.test(r.url));
}

async function wordpress(base: string, label: string, q: string): Promise<RawResult[]> {
  const { status, text } = await fetchText(
    `${base}/wp-json/wp/v2/posts?search=${encodeURIComponent(q)}&per_page=6&_fields=title,link,excerpt,content`,
    { headers: { Accept: "application/json" } },
    15000,
  );
  if (status !== 200) throw new Error(`HTTP ${status}`);
  const data = JSON.parse(text) as Array<{
    title?: { rendered?: string };
    link?: string;
    excerpt?: { rendered?: string };
    content?: { rendered?: string };
  }>;
  if (!Array.isArray(data)) return [];
  return data
    .filter((p) => typeof p.link === "string")
    .map((p) => ({
      title: stripHtml(p.title?.rendered ?? ""),
      url: p.link as string,
      snippet: clip(stripHtml(p.excerpt?.rendered ?? ""), 320),
      content: stripHtml(p.content?.rendered ?? ""),
      engine: label,
    }));
}

async function tavily(q: string): Promise<RawResult[]> {
  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.TAVILY_API_KEY}` },
    body: JSON.stringify({ query: q, search_depth: "basic", max_results: 8, include_domains: TOP_PORTAL_DOMAINS }),
    signal: AbortSignal.timeout(12000),
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = (await res.json()) as { results?: Array<{ title?: string; url?: string; content?: string }> };
  return (data.results ?? [])
    .filter((r) => r.url)
    .map((r) => ({ title: r.title ?? "", url: r.url as string, snippet: clip(r.content ?? "", 400), content: r.content, engine: "Tavily" }));
}

async function serper(q: string): Promise<RawResult[]> {
  const res = await fetch("https://google.serper.dev/search", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-API-KEY": process.env.SERPER_API_KEY || "" },
    body: JSON.stringify({ q, gl: "br", hl: "pt-br", num: 10 }),
    signal: AbortSignal.timeout(12000),
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = (await res.json()) as { organic?: Array<{ title?: string; link?: string; snippet?: string }> };
  return (data.organic ?? [])
    .filter((r) => r.link)
    .map((r) => ({ title: r.title ?? "", url: r.link as string, snippet: r.snippet ?? "", engine: "Google" }));
}

async function brave(q: string): Promise<RawResult[]> {
  const res = await fetch(
    `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(q)}&country=BR&search_lang=pt-br&count=10`,
    {
      headers: { Accept: "application/json", "X-Subscription-Token": process.env.BRAVE_SEARCH_API_KEY || "" },
      signal: AbortSignal.timeout(12000),
      cache: "no-store",
    },
  );
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = (await res.json()) as { web?: { results?: Array<{ title?: string; url?: string; description?: string }> } };
  return (data.web?.results ?? [])
    .filter((r) => r.url)
    .map((r) => ({ title: stripHtml(r.title ?? ""), url: r.url as string, snippet: stripHtml(r.description ?? ""), engine: "Brave" }));
}

export function searchProvidersLabel(): string[] {
  const list: string[] = [];
  if (process.env.TAVILY_API_KEY) list.push("Tavily");
  if (process.env.SERPER_API_KEY) list.push("Google (Serper)");
  if (process.env.BRAVE_SEARCH_API_KEY) list.push("Brave Search");
  list.push("DuckDuckGo", "Bing", "Blogs dos portais (Gran, AlfaCon)");
  return list;
}

/* ------------------------ Relevância e leitura ------------------------ */

const GENERIC = new Set(["direito", "nocoes", "legislacao", "conhecimentos", "lingua", "basicos", "gerais", "especificos", "nivel", "medio"]);
const JUNK = /(youtube\.com|youtu\.be|facebook\.com|instagram\.com|tiktok\.com|twitter\.com|\bx\.com|amazon\.|mercadolivre|wikipedia\.org|pinterest\.|scribd\.com|studocu\.com|passeidireto\.com)/i;

function subjectMatchers(subject: string): { required: RegExp[]; all: RegExp[] } {
  const toks = tokens(subject);
  const specific = toks.filter((t) => !GENERIC.has(t));
  const mk = (t: string) => new RegExp(`\\b${escapeRe(stem(t))}`);
  return { required: (specific.length ? specific : toks).map(mk), all: toks.map(mk) };
}

const ANALYSIS = /mais cobrad|mais cai|que mais caem|incidencia|estatistic|ranking|o que estudar|perfil da banca|como a fcc|temas mais|assuntos mais|topicos mais/;
const NEWS = /\b(autorizad\w*|edital|editais|inscric\w*|vagas|salario\w*|nomea\w*|nomeia|resultado|gabarito|banca definida|retificad\w*|homologad\w*|convoca\w*|cronograma|contrato|previsto|iminente|ofertad\w*|abre|abertas|aniversario|reta final|aulas gratuitas|eventos)\b/;
const FCC_RE = /\bfcc\b|carlos chagas/;
/** Conteúdos focados em outras bancas não servem para medir a incidência da FCC. */
const OTHER_BANKS = /\b(cesgranrio|cebraspe|cespe|fgv|vunesp|funpar|ibfc|quadrix|idecan|fundatec|aocp|consulplan|ibade|iades|cetro|fepese|selecon)\b/;

function scoreResult(r: RawResult, m: { required: RegExp[]; all: RegExp[] }): number {
  const ts = normalize(`${r.title} ${r.snippet}`);
  const content = normalize((r.content ?? "").slice(0, 8000));
  const need = m.required.length ? Math.max(1, Math.ceil(m.required.length / 2)) : 0;
  const reqTS = m.required.filter((re) => re.test(ts)).length;
  const reqC = m.required.filter((re) => re.test(content)).length;
  const analysisTS = ANALYSIS.test(ts);
  const analysisC = ANALYSIS.test(content);
  // O assunto precisa aparecer no título/trecho, ou no conteúdo de uma análise de incidência.
  if (reqTS < need && !(reqC >= need && analysisC)) return -1;
  let s = reqTS * 3 + Math.min(reqC, 3);
  if (portalFor(r.url)) s += 5;
  if (FCC_RE.test(ts) || FCC_RE.test(content)) s += 3;
  if (analysisTS) s += 4;
  else if (analysisC) s += 2;
  if (NEWS.test(normalize(r.title)) && !analysisTS) s -= 6;
  if (OTHER_BANKS.test(ts) && !FCC_RE.test(ts)) s -= 8;
  if (JUNK.test(r.url)) s -= 6;
  return s;
}

function canonical(url: string): string {
  try {
    const u = new URL(url);
    return `${u.hostname.replace(/^www\./, "")}${u.pathname.replace(/\/+$/, "")}`.toLowerCase();
  } catch {
    return url;
  }
}

async function readPage(url: string): Promise<string> {
  try {
    const { status, text } = await fetchText(url, { headers: { Accept: "text/html" } }, 7000);
    if (status !== 200) return "";
    if (/Checking your browser|captcha|Human Verification|cf-browser-verification|Just a moment/i.test(text.slice(0, 6000))) return "";
    const articles = text.match(/<article[\s\S]*?<\/article>/gi) ?? [];
    const main = articles.sort((a, b) => b.length - a.length)[0] ?? text.match(/<main[\s\S]*?<\/main>/i)?.[0] ?? text;
    return stripHtml(main.replace(/<(header|footer|nav|aside|form)[^>]*>[\s\S]*?<\/\1>/gi, " "));
  } catch {
    return "";
  }
}

function relevantExcerpt(text: string, subject: string, max = 2200): string {
  if (!text) return "";
  const m = subjectMatchers(subject);
  const chunks = text
    .split(/\n+/)
    .flatMap((p) => (p.length > 600 ? p.match(/[^.!?]+[.!?]+/g) ?? [p] : [p]))
    .map((c) => c.trim())
    .filter((c) => c.length > 30);
  const scored = chunks.map((c, i) => {
    const n = normalize(c);
    let s = m.all.filter((re) => re.test(n)).length * 2;
    if (/mais cobrad|mais cai|incidencia|questoes|\bfcc\b|carlos chagas|%|assunto/.test(n)) s += 1;
    if (/^\d+[.)ºo°]|^[-•–]/.test(c)) s += 1;
    return { c, i, s };
  });
  const top = scored
    .filter((x) => x.s > 0)
    .sort((a, b) => b.s - a.s)
    .slice(0, 16)
    .sort((a, b) => a.i - b.i);
  let out = "";
  for (const x of top) {
    if (out.length + x.c.length > max) break;
    out += (out ? "\n" : "") + x.c;
  }
  return out || clip(text, max);
}

/* ------------------------------ Orquestração ------------------------------ */

export interface PortalSearchOutput {
  sources: ResearchSource[];
  extracts: Record<number, string>;
  log: string[];
}

export async function searchPortals(subject: string, cargo?: string | null): Promise<PortalSearchOutput> {
  const log: string[] = [];
  const subj = subject.trim();
  const short = subj.split(/\s+/).slice(0, 4).join(" ");
  const q1 = `assuntos mais cobrados FCC ${subj}`;
  const q2 = `${subj} Fundação Carlos Chagas o que mais cai${cargo ? ` ${cargo}` : ""}`;
  const siteFilter = `(${TOP_PORTAL_DOMAINS.slice(0, 6).map((d) => `site:${d}`).join(" OR ")})`;

  const tasks: Promise<RawResult[]>[] = [];
  const run = (label: string, fn: () => Promise<RawResult[]>) => {
    tasks.push(
      fn()
        .then((r) => {
          log.push(`${label}: ${r.length} resultado(s)`);
          return r;
        })
        .catch((e: unknown) => {
          log.push(`${label}: indisponível (${clip(String((e as Error)?.message ?? e), 60)})`);
          return [] as RawResult[];
        }),
    );
  };

  if (process.env.TAVILY_API_KEY) run("Tavily", async () => [...(await tavily(q1)), ...(await tavily(q2).catch(() => []))]);
  if (process.env.SERPER_API_KEY) run("Google (Serper)", async () => [...(await serper(`${q1} ${siteFilter}`)), ...(await serper(q2).catch(() => []))]);
  if (process.env.BRAVE_SEARCH_API_KEY) run("Brave Search", () => brave(q1));
  run("DuckDuckGo", async () => {
    const a = await duckduckgo(q1);
    await sleep(900);
    const b = await duckduckgo(q2).catch(() => [] as RawResult[]);
    return [...a, ...b];
  });
  run("Bing", async () => {
    const [a, b] = await Promise.all([bingRss(q1), bingRss(`FCC ${subj} mais cobrados concursos`).catch(() => [] as RawResult[])]);
    return [...a, ...b];
  });
  run("Gran Cursos (blog)", async () => {
    const [a, b] = await Promise.all([
      wordpress("https://blog.grancursosonline.com.br", "Gran Cursos (blog)", `FCC ${short}`),
      wordpress("https://blog.grancursosonline.com.br", "Gran Cursos (blog)", `mais cobrados ${short}`).catch(() => [] as RawResult[]),
    ]);
    return [...a, ...b];
  });
  run("AlfaCon (blog)", () => wordpress("https://blog.alfaconcursos.com.br", "AlfaCon (blog)", `mais cobrados ${short}`));

  const all = (await Promise.all(tasks)).flat();
  const matchers = subjectMatchers(subj);
  const byUrl = new Map<string, RawResult & { score: number }>();
  const relevantByEngine = new Map<string, number>();
  for (const r of all) {
    if (!r.url || !r.title) continue;
    const score = scoreResult(r, matchers);
    if (score < 0) continue;
    if (score >= 9) relevantByEngine.set(r.engine, (relevantByEngine.get(r.engine) ?? 0) + 1);
    const key = canonical(r.url);
    const prev = byUrl.get(key);
    if (!prev || prev.score < score) byUrl.set(key, { ...r, score });
  }
  const ranked = Array.from(byUrl.values()).sort((a, b) => b.score - a.score);
  const portals = ranked.filter((r) => portalFor(r.url) && r.score >= 9);
  const others = ranked.filter((r) => !portalFor(r.url) && r.score >= 12 && !JUNK.test(r.url));
  if (relevantByEngine.size)
    log.push(`Relevantes por fonte: ${Array.from(relevantByEngine.entries()).map(([k, v]) => `${k} ${v}`).join(" · ")}`);
  const chosen = [...portals.slice(0, 10), ...(portals.length < 4 ? others.slice(0, 4 - portals.length) : [])].slice(0, 10);

  const sources: ResearchSource[] = chosen.map((r, i) => {
    const portal = portalFor(r.url);
    return {
      id: i + 1,
      title: clip(r.title, 160),
      url: r.url,
      snippet: clip(r.snippet, 320),
      portal: portal?.name ?? hostOf(r.url),
      domain: hostOf(r.url),
      engine: r.engine,
      isPortal: Boolean(portal),
    };
  });

  const extracts: Record<number, string> = {};
  await Promise.all(
    chosen.slice(0, 6).map(async (r, i) => {
      const text = r.content && r.content.length > 200 ? r.content : i < 4 ? await readPage(r.url) : "";
      const ex = relevantExcerpt(text, subj);
      if (ex) extracts[i + 1] = ex;
    }),
  );
  log.push(`Fontes selecionadas: ${sources.length} (${sources.filter((s) => s.isPortal).length} de portais de concursos)`);
  return { sources, extracts, log };
}
