import { normalize } from "./text";
import type { RelevanceLevel } from "./types";

export interface RefTopic {
  name: string;
  relevance: number;
  why: string;
}

export interface SubjectDef {
  key: string;
  label: string;
  aliases: string[];
  /** Assuntos do banco curado que podem ser usados para esta matéria. */
  bank: string[];
  reference: RefTopic[];
}

const t = (name: string, relevance: number, why: string): RefTopic => ({ name, relevance, why });

/** Ordem importa: diplomas específicos antes das matérias amplas. */
export const SUBJECTS: SubjectDef[] = [
  {
    key: "lei8112",
    label: "Lei nº 8.112/1990",
    aliases: ["8112", "regime juridico", "servidores publicos civis", "servidor publico federal", "estatuto do servidor"],
    bank: ["lei8112"],
    reference: [
      t("Provimento, posse e exercício", 95, "Prazos de posse/exercício e formas de provimento aparecem em quase toda prova."),
      t("Penalidades disciplinares", 92, "A FCC cobra a literalidade das hipóteses, prazos e cancelamento de registros."),
      t("Processo administrativo disciplinar e sindicância", 85, "Prazos, comissão e afastamento preventivo são alvos frequentes."),
      t("Vacância, remoção e redistribuição", 78, "Conceitos parecidos que a banca troca entre si nas alternativas."),
      t("Direitos e vantagens: férias, licenças e concessões", 76, "Prazos de concessões e licenças são típicos de 'letra da lei'."),
      t("Deveres e proibições do servidor", 74, "Listas dos arts. 116 e 117 com trocas sutis de palavras."),
      t("Estágio probatório e estabilidade", 65, "Fatores de avaliação e recondução por inabilitação."),
      t("Responsabilidades civil, penal e administrativa", 55, "Independência das instâncias e absolvição criminal."),
    ],
  },
  {
    key: "lei9784",
    label: "Processo Administrativo (Lei nº 9.784/1999)",
    aliases: ["9784", "processo administrativo"],
    bank: ["lei9784"],
    reference: [
      t("Recurso administrativo e revisão", 92, "Prazos de 10 dias, 3 instâncias e reformatio in pejus."),
      t("Competência, delegação e avocação", 90, "O art. 13 (o que não pode ser delegado) é campeão de cobrança."),
      t("Impedimento e suspeição", 80, "A banca mistura as hipóteses dos arts. 18 e 20."),
      t("Prazos, forma, tempo e lugar dos atos", 74, "Prazo geral de 5 dias e contagem de prazos."),
      t("Anulação, revogação e convalidação", 72, "Decadência de 5 anos para anular atos favoráveis."),
      t("Princípios e direitos dos administrados", 60, "Rol do art. 2º e direitos do art. 3º."),
      t("Prioridade de tramitação", 45, "Idosos, pessoas com deficiência e doenças graves (art. 69-A)."),
    ],
  },
  {
    key: "lai",
    label: "Lei de Acesso à Informação (Lei nº 12.527/2011)",
    aliases: ["12527", "acesso a informacao", "\\blai\\b"],
    bank: ["lai"],
    reference: [
      t("Procedimento de acesso e prazos de resposta", 94, "Prazo de 20 dias prorrogável por 10 é pergunta recorrente."),
      t("Classificação da informação e prazos de sigilo", 92, "25, 15 e 5 anos: a FCC troca os números."),
      t("Transparência ativa e passiva", 70, "O que deve ser divulgado independentemente de requerimento."),
      t("Recursos contra negativa de acesso", 68, "Prazo de 10 dias e autoridade hierarquicamente superior."),
      t("Informações pessoais", 60, "Restrição de até 100 anos e hipóteses de acesso."),
      t("Responsabilidades dos agentes", 45, "Condutas ilícitas e sanções."),
    ],
  },
  {
    key: "pcd",
    label: "Estatuto da Pessoa com Deficiência (Lei nº 13.146/2015)",
    aliases: ["13146", "pessoa com deficiencia", "deficiencia", "inclusao", "\\bpcd\\b", "acessibilidade"],
    bank: ["pcd"],
    reference: [
      t("Conceitos: pessoa com deficiência, barreiras e acessibilidade", 94, "O art. 2º e o rol de barreiras do art. 3º são muito cobrados."),
      t("Igualdade, não discriminação e capacidade civil", 82, "A deficiência não afeta a plena capacidade civil (art. 6º)."),
      t("Curatela e tomada de decisão apoiada", 78, "Curatela restrita a atos patrimoniais e negociais."),
      t("Direitos fundamentais: saúde, educação e trabalho", 72, "Direitos com prazos e percentuais específicos."),
      t("Acessibilidade e tecnologia assistiva", 60, "Desenho universal e adaptações razoáveis."),
      t("Crimes e infrações administrativas", 50, "Tipos penais e penas previstas no Estatuto."),
    ],
  },
  {
    key: "etica",
    label: "Ética no Serviço Público",
    aliases: ["etica", "1171", "codigo de etica", "conduta do servidor"],
    bank: ["etica"],
    reference: [
      t("Decreto nº 1.171/1994: regras deontológicas", 95, "A FCC transcreve os incisos e troca poucas palavras."),
      t("Deveres fundamentais do servidor", 85, "Rol do inciso XIV."),
      t("Vedações ao servidor público", 84, "Rol do inciso XV, muitas vezes misturado com deveres."),
      t("Comissões de Ética e pena de censura", 80, "Única pena aplicável pela Comissão de Ética."),
      t("Ética, moral e princípios da Administração", 55, "Moralidade administrativa e finalidade."),
      t("Conflito de interesses (Lei nº 12.813/2013)", 45, "Situações de conflito durante e após o exercício."),
    ],
  },
  {
    key: "portugues",
    label: "Língua Portuguesa",
    aliases: ["portugues", "portuguesa", "gramatica", "interpretacao de texto", "lingua patria"],
    bank: ["portugues"],
    reference: [
      t("Compreensão e interpretação de textos", 96, "Presente em praticamente todas as provas da FCC."),
      t("Concordância verbal e nominal", 90, "Sujeito posposto e verbos impessoais são clássicos."),
      t("Reescrita de frases e substituição de segmentos", 86, "Manutenção do sentido e da correção gramatical."),
      t("Pontuação (emprego da vírgula)", 82, "Vírgula entre sujeito e verbo e orações adverbiais."),
      t("Crase", 78, "Casos proibidos e facultativos."),
      t("Regência verbal e nominal", 76, "Verbos como assistir, visar, aspirar e preferir."),
      t("Pronomes: emprego e colocação pronominal", 74, "Próclise obrigatória e pronomes relativos."),
      t("Conjunções e relações de sentido (coesão)", 72, "Valor semântico dos conectivos."),
      t("Tempos e modos verbais", 60, "Correlação verbal e formas do subjuntivo."),
    ],
  },
  {
    key: "constitucional",
    label: "Direito Constitucional",
    aliases: ["constitucional", "constituicao", "cf88", "cf/88", "direitos fundamentais"],
    bank: ["constitucional"],
    reference: [
      t("Direitos e garantias fundamentais (art. 5º)", 96, "O artigo mais cobrado da Constituição."),
      t("Administração Pública (arts. 37 a 41)", 92, "Concurso público, acumulação e estabilidade."),
      t("Remédios constitucionais", 82, "HC, HD, MS, MI e ação popular."),
      t("Organização do Estado e repartição de competências", 76, "Competências da União, Estados e Municípios."),
      t("Poder Judiciário: organização e competências", 72, "Muito frequente em provas de tribunais."),
      t("Direitos políticos e nacionalidade", 70, "Voto facultativo e cargos privativos de brasileiro nato."),
      t("Princípios fundamentais (arts. 1º a 4º)", 62, "Fundamentos x objetivos da República."),
      t("Poder Legislativo e processo legislativo", 55, "Espécies normativas e quóruns."),
    ],
  },
  {
    key: "administrativo",
    label: "Direito Administrativo",
    aliases: ["administrativo", "administracao publica", "improbidade", "8429", "licitac", "14133", "atos administrativos"],
    bank: ["administrativo", "lei9784", "lei8112"],
    reference: [
      t("Atos administrativos: atributos, elementos e extinção", 95, "Anulação x revogação é tema campeão."),
      t("Poderes administrativos", 86, "Poder de polícia, hierárquico, disciplinar e regulamentar."),
      t("Organização administrativa", 84, "Autarquias, empresas estatais, desconcentração x descentralização."),
      t("Agentes públicos e regime jurídico", 82, "Cargos, empregos e funções; Lei nº 8.112/1990."),
      t("Licitações e contratos (Lei nº 14.133/2021)", 80, "Modalidades, critérios de julgamento e contratação direta."),
      t("Improbidade administrativa (Lei nº 8.429/1992)", 78, "Exigência de dolo após a Lei nº 14.230/2021."),
      t("Princípios da Administração Pública", 74, "LIMPE e princípios implícitos."),
      t("Responsabilidade civil do Estado", 70, "Art. 37, § 6º, da CF: responsabilidade objetiva."),
      t("Controle da Administração e serviços públicos", 58, "Autotutela, controle judicial e concessões."),
    ],
  },
  {
    key: "informatica",
    label: "Noções de Informática",
    aliases: ["informatica", "computacao", "tecnologia da informacao", "excel", "windows", "office", "seguranca da informacao", "internet"],
    bank: ["informatica"],
    reference: [
      t("Planilhas (Excel/Calc): fórmulas, funções e referências", 94, "Cálculo de fórmulas copiadas e funções como SE e PROCV."),
      t("Segurança da informação: malwares, golpes e backup", 92, "Ransomware, phishing, worms e tipos de backup."),
      t("Windows 10/11: conceitos e atalhos", 80, "Atalhos de teclado e Explorador de Arquivos."),
      t("Editores de texto (Word/Writer)", 78, "Formatação, atalhos e recursos de revisão."),
      t("Internet, navegadores e correio eletrônico", 76, "Protocolos SMTP, POP3 e IMAP; navegação anônima."),
      t("Redes de computadores e protocolos", 58, "TCP/IP, DNS, HTTP/HTTPS."),
      t("Computação em nuvem", 52, "Modelos de serviço e armazenamento."),
    ],
  },
  {
    key: "raciocinio",
    label: "Raciocínio Lógico-Matemático",
    aliases: ["raciocinio", "logica", "logico"],
    bank: ["raciocinio"],
    reference: [
      t("Sequências lógicas (números, letras e figuras)", 94, "Marca registrada da FCC em nível médio."),
      t("Problemas aritméticos: frações, porcentagem, razão e proporção", 92, "Questões contextualizadas do cotidiano."),
      t("Proposições, conectivos, equivalências e negações", 84, "Negação de 'todo' e equivalências do 'se... então'."),
      t("Regra de três simples e composta", 78, "Grandezas direta e inversamente proporcionais."),
      t("Lógica de argumentação e diagramas", 70, "Quantificadores todo, algum e nenhum."),
      t("Problemas com datas, calendários e horários", 58, "Contagem de dias e dias da semana."),
      t("Análise combinatória e probabilidade básica", 50, "Princípio fundamental da contagem."),
    ],
  },
  {
    key: "matematica",
    label: "Matemática",
    aliases: ["matematica", "aritmetica", "porcentagem", "financeira"],
    bank: ["raciocinio"],
    reference: [
      t("Porcentagem e variações percentuais", 94, "Aumentos e descontos sucessivos."),
      t("Razão, proporção e regra de três", 90, "Divisão proporcional e grandezas."),
      t("Frações e operações com números racionais", 80, "Problemas de partilha."),
      t("Equações e sistemas do 1º grau", 72, "Problemas de idades e quantidades."),
      t("Juros simples e compostos", 62, "Montante e taxa equivalente."),
      t("MMC e MDC", 55, "Eventos periódicos e divisões exatas."),
      t("Sistemas de medidas e tempo", 50, "Conversões de unidades."),
    ],
  },
  {
    key: "arquivologia",
    label: "Arquivologia",
    aliases: ["arquivologia", "arquivistica", "gestao documental", "nocoes de arquivo"],
    bank: ["arquivologia"],
    reference: [
      t("Teoria das três idades (ciclo vital dos documentos)", 92, "Arquivos corrente, intermediário e permanente."),
      t("Gestão de documentos: produção, tramitação e destinação", 86, "Lei nº 8.159/1991."),
      t("Classificação e tabela de temporalidade", 80, "Instrumentos de gestão."),
      t("Métodos de arquivamento", 74, "Alfabético, numérico, geográfico, ideográfico."),
      t("Protocolo: recebimento, registro e expedição", 66, "Rotinas de protocolo."),
      t("Princípios arquivísticos", 60, "Proveniência, organicidade, indivisibilidade."),
      t("Preservação e conservação de documentos", 52, "Fatores de deterioração."),
    ],
  },
  {
    key: "penal",
    label: "Direito Penal",
    aliases: ["penal", "codigo penal", "crimes contra a administracao"],
    bank: ["penal"],
    reference: [
      t("Crimes contra a Administração Pública", 95, "Peculato, concussão, corrupção e prevaricação."),
      t("Teoria do crime: tipicidade, ilicitude e culpabilidade", 80, "Excludentes de ilicitude."),
      t("Aplicação da lei penal", 70, "Tempo e lugar do crime."),
      t("Concurso de pessoas", 60, "Autoria e participação."),
      t("Penas e extinção da punibilidade", 55, "Espécies de penas e prescrição."),
      t("Crimes contra a pessoa e o patrimônio", 50, "Furto, roubo e estelionato."),
    ],
  },
];

/** Temas pontuais campeões de cobrança na FCC (para treino com Foco 100% no tema). */
export const FOCUSED_SUGGESTIONS = [
  "Crase",
  "Concordância Verbal e Nominal",
  "Atos Administrativos",
  "Licitações e Contratos (Lei 14.133/2021)",
  "Improbidade Administrativa (Lei 8.429/92)",
  "Poderes Administrativos",
  "Direitos e Garantias Fundamentais (Art. 5º CF)",
  "Remédios Constitucionais",
  "Planilhas Excel: Fórmulas e Funções",
  "Segurança da Informação, Malwares e Backup",
  "Crimes contra a Administração Pública",
  "Teoria das Três Idades (Arquivologia)",
];

export const SUGGESTIONS = [
  "Língua Portuguesa",
  "Direito Constitucional",
  "Direito Administrativo",
  "Lei nº 8.112/1990",
  "Noções de Informática",
  "Raciocínio Lógico-Matemático",
  "Ética no Serviço Público",
  "Processo Administrativo (Lei 9.784/99)",
  "Lei de Acesso à Informação",
  "Estatuto da Pessoa com Deficiência",
  "Arquivologia",
  "Direito Penal",
];

export function matchSubject(input: string): SubjectDef | null {
  const n = normalize(input).replace(/[^a-z0-9/ ]/g, " ").replace(/\s+/g, " ");
  for (const s of SUBJECTS) {
    for (const alias of s.aliases) {
      if (alias.startsWith("\\b")) {
        if (new RegExp(alias).test(n)) return s;
      } else if (n.includes(alias)) {
        return s;
      }
    }
  }
  return null;
}

export function levelFor(relevance: number): RelevanceLevel {
  if (relevance >= 85) return "Altíssima";
  if (relevance >= 70) return "Alta";
  if (relevance >= 50) return "Média";
  return "Baixa";
}
