export const LETTERS = ["A", "B", "C", "D", "E"] as const;
export type Letter = (typeof LETTERS)[number];
export type Options = Record<Letter, string>;

export function isLetter(v: unknown): v is Letter {
  return typeof v === "string" && (LETTERS as readonly string[]).includes(v);
}

export type RelevanceLevel = "Altíssima" | "Alta" | "Média" | "Baixa";

export interface ResearchSource {
  id: number;
  title: string;
  url: string;
  snippet: string;
  portal: string;
  domain: string;
  engine: string;
  isPortal: boolean;
}

export interface ResearchTopic {
  name: string;
  relevance: number;
  level: RelevanceLevel;
  why: string;
  sources: number[];
}

/** web+ia = busca ao vivo + síntese por IA; ia = só conhecimento da IA; web = busca + base; referencia = base interna */
export type ResearchMethod = "web+ia" | "ia" | "web" | "referencia";

export interface ResearchResult {
  id: string;
  subject: string;
  cargo: string | null;
  topics: ResearchTopic[];
  sources: ResearchSource[];
  summary: string;
  styleTips: string[];
  searchLog: string[];
  method: ResearchMethod;
  engine: string;
  createdAt: string;
  cached?: boolean;
}

export interface GeneratedQuestion {
  topic: string;
  supportText: string | null;
  statement: string;
  options: Options;
  correct: Letter;
  summary: string;
  legalBasis: string | null;
  lawText: string | null;
  analysis: Partial<Record<Letter, string>>;
  tip: string | null;
  difficulty: string | null;
}

export interface BankQuestion extends GeneratedQuestion {
  id: string;
  subject: string;
}

export interface PlanItem {
  position: number;
  topic: string;
  letter: Letter;
}

export type QuizMode = "estudo" | "simulado";
export type QuizStatus = "generating" | "ready" | "finished";
export type QuestionOrigin = "ia" | "ia-gratuita" | "banco";

export interface Correction {
  correct: Letter;
  isCorrect: boolean | null;
  summary: string;
  legalBasis: string | null;
  lawText: string | null;
  lawUrl: string | null;
  analysis: Partial<Record<Letter, string>>;
  tip: string | null;
  difficulty: string | null;
}

export interface PublicQuestion {
  id: string;
  position: number;
  topic: string;
  supportText: string | null;
  statement: string;
  options: Options;
  origin: QuestionOrigin;
  engine: string | null;
  userAnswer: Letter | null;
  revealed: boolean;
  correction?: Correction;
}

export interface PublicQuiz {
  id: string;
  subject: string;
  cargo: string | null;
  topics: string[];
  mode: QuizMode;
  status: QuizStatus;
  questionCount: number;
  answeredCount: number;
  correctCount: number;
  engine: string | null;
  createdAt: string;
  finishedAt: string | null;
  /** Plano sem as letras do gabarito (apenas posição e tema). */
  plan: { position: number; topic: string }[];
  batchSize: number;
  concurrency: number;
  questions: PublicQuestion[];
}

export interface EngineStatus {
  ai: { id: string; label: string; model: string; premium: boolean };
  search: string[];
  bankSize: number;
}
